<script setup lang="ts">
import { computed, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import GiftEditor from './components/GiftEditor.vue'
import originalGift from './default-gift.json'
import { decodeGift, validateGift, type GiftContent } from './content'
import LoginPage from './components/LoginPage.vue'
import ParticlePage from './components/ParticlePage.vue'
import StoryPage from './components/StoryPage.vue'
import WishesPage from './components/WishesPage.vue'
import { loadProgress, saveProgress, clearProgress, pageForKey } from './navigation'
import { applyUpdate } from './pwa'

const gift = ref<GiftContent>(validateGift(originalGift))
const loading = ref(true)
const linkError = ref('')
const editorOpen = ref(false)
const previewing = ref(false)
const entered = ref(false)
const currentPage = ref(0)
let loadNumber = 0
async function loadLink() {
  const number = ++loadNumber
  loading.value = true
  linkError.value = ''
  try {
    const content = await decodeGift(window.location.hash)
    if (number !== loadNumber) return
    gift.value = content ?? validateGift(originalGift)
    const progress = loadProgress(gift.value.id)
    entered.value = progress !== null
    currentPage.value = progress?.page ?? 0
    transitioning.value = false
    previewing.value = false
    document.title = `${gift.value.greeting}，${gift.value.recipient}`
    if (new URLSearchParams(window.location.search).has('edit')) editorOpen.value = true
  } catch (cause) {
    if (number === loadNumber) linkError.value = (cause as Error).message
  } finally { if (number === loadNumber) loading.value = false }
}
function showOriginal() {
  history.replaceState(null, '', window.location.pathname)
  void loadLink()
}
async function preview(content: GiftContent) {
  gift.value = content
  previewing.value = true
  entered.value = true
  currentPage.value = 0
  transitioning.value = false
  editorOpen.value = false
  await nextTick()
  pageHost.value?.querySelector<HTMLElement>('h1')?.focus({ preventScroll: true })
}
const transitioning = ref(false)
const hidden = ref(document.hidden)
const reduceMotion = ref(window.matchMedia('(prefers-reduced-motion: reduce)').matches)
const online = ref(navigator.onLine)
const offlineReady = ref(false)
const updateReady = ref(false)
const pageHost = ref<HTMLElement | null>(null)
const pages = [
  { name: '生日', title: '生日快乐', component: ParticlePage },
  { name: '故事', title: '人生剧本', component: StoryPage },
  { name: '寄语', title: '人生寄语', component: WishesPage },
]
const active = computed(() => !hidden.value && !reduceMotion.value && !editorOpen.value)
const connectionText = computed(() => !online.value
  ? offlineReady.value ? '当前离线，仍可浏览和互动' : '当前离线，请勿关闭此页'
  : offlineReady.value ? '已保存，可离线打开' : '')

function enter() {
  entered.value = true
  currentPage.value = 0
  saveProgress(0, gift.value.id)
}
function goTo(index: number) {
  if (transitioning.value || index < 0 || index >= pages.length || currentPage.value === index) return
  transitioning.value = true
  currentPage.value = index
}
function finishTransition() {
  transitioning.value = false
  pageHost.value?.querySelector<HTMLElement>('h1')?.focus({ preventScroll: true })
}
function restart() {
  clearProgress(gift.value.id)
  entered.value = false
  currentPage.value = 0
  transitioning.value = false
}
function onKey(event: KeyboardEvent) {
  if (!entered.value || editorOpen.value || loading.value || event.altKey || event.ctrlKey || event.metaKey) return
  const tag = (event.target as HTMLElement).tagName
  const editing = ['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON', 'A', 'SUMMARY'].includes(tag)
    || (event.target as HTMLElement).isContentEditable
  const index = pageForKey(currentPage.value, event.key, editing)
  if (index !== currentPage.value) {
    event.preventDefault()
    goTo(index)
  }
}
function onVisibility() { hidden.value = document.hidden }
function onNetwork() { online.value = navigator.onLine }
function onOfflineReady() { offlineReady.value = true }
function onUpdateReady() { updateReady.value = true }

watch(currentPage, page => { if (entered.value && !loading.value && !previewing.value) saveProgress(page, gift.value.id) })
onMounted(() => {
  void loadLink()
  window.addEventListener('hashchange', loadLink)
  window.addEventListener('keydown', onKey)
  document.addEventListener('visibilitychange', onVisibility)
  window.addEventListener('online', onNetwork)
  window.addEventListener('offline', onNetwork)
  window.addEventListener('gift-offline-ready', onOfflineReady)
  window.addEventListener('gift-update-ready', onUpdateReady)
  if ('serviceWorker' in navigator && navigator.serviceWorker.controller) offlineReady.value = true
})
onUnmounted(() => {
  window.removeEventListener('hashchange', loadLink)
  window.removeEventListener('keydown', onKey)
  document.removeEventListener('visibilitychange', onVisibility)
  window.removeEventListener('online', onNetwork)
  window.removeEventListener('offline', onNetwork)
  window.removeEventListener('gift-offline-ready', onOfflineReady)
  window.removeEventListener('gift-update-ready', onUpdateReady)
})
</script>

<template>
  <div class="gift-app" :class="{ 'reduced-motion': reduceMotion }">
    <div v-if="loading" class="loading-gift" role="status">正在打开这份礼物…</div>
    <div v-else-if="linkError" class="link-error" role="alert"><h1>这份链接暂时打不开</h1><p>{{ linkError }}</p><button @click="showOriginal">查看原始示例</button></div>
    <LoginPage v-else-if="!entered" :key="gift.id" :gift="gift" @login="enter" />
    <template v-else>
      <header class="experience-tools">
        <button v-if="updateReady" class="update-button" aria-label="新版本可用，刷新" @click="applyUpdate"><span class="update-full">新版本可用，刷新</span><span class="update-short">刷新新版</span></button>
        <span v-else class="connection-note" role="status">{{ previewing ? "正在预览你的草稿" : connectionText }}</span>
        <button class="motion-toggle" :aria-pressed="reduceMotion" @click="reduceMotion = !reduceMotion">
          {{ reduceMotion ? '开启动效' : '减少动效' }}
        </button>
      </header>
      <main ref="pageHost" class="page-host" :aria-busy="transitioning">
        <Transition name="page" mode="out-in" @after-enter="finishTransition" @enter-cancelled="finishTransition">
          <component :is="pages[currentPage]!.component" :key="`${gift.id}-${currentPage}`" :is-active="active" :gift="gift"
            @next="goTo(currentPage + 1)" @restart="restart" />
        </Transition>
      </main>
      <nav class="page-navigation" aria-label="礼物页面">
        <button class="arrow" aria-label="上一页" :disabled="currentPage === 0 || transitioning" @click="goTo(currentPage - 1)">‹</button>
        <div class="page-tabs">
          <button v-for="(page, index) in pages" :key="page.name" :aria-label="page.title"
            :aria-current="currentPage === index ? 'page' : undefined" :disabled="transitioning"
            @click="goTo(index)">{{ page.name }}</button>
        </div>
        <button class="arrow" aria-label="下一页" :disabled="currentPage === 2 || transitioning" @click="goTo(currentPage + 1)">›</button>
      </nav>
      <p class="sr-only" aria-live="polite">第 {{ currentPage + 1 }} 页，共 3 页：{{ pages[currentPage]!.title }}</p>
    </template>
    <button v-if="!loading && !linkError" class="edit-launcher" :class="{ 'on-invitation': !entered }" @click="editorOpen = true">{{ previewing ? '继续编辑' : '制作我的祝福' }}</button>
    <GiftEditor v-if="editorOpen" :gift="gift" @close="editorOpen = false" @preview="preview" />
  </div>
</template>

<style scoped>
.loading-gift, .link-error { height: 100%; display: flex; gap: 24px; flex-direction: column; align-items: center; justify-content: center; padding: 32px; text-align: center; }
.link-error p { max-width: 40ch; line-height: 1.8; }.link-error button { min-height: 48px; padding: 12px 24px; background: #353148; color: white; border: 1px solid #aaa; border-radius: 8px; }
.edit-launcher { position: absolute; z-index: 11; top: max(12px, env(safe-area-inset-top)); right: 132px; min-height: 44px; padding: 8px 12px; background: #090b16df; border: 1px solid #ffffff30; border-radius: 8px; color: #e2e8f0; font-size: 13px; }
.edit-launcher.on-invitation { right: 20px; background: #fff; border-color: #8b8795; color: #44325c; }
.gift-app, .page-host { width: 100%; height: 100%; position: relative; overflow: hidden; }
.experience-tools { position: absolute; inset: max(12px, env(safe-area-inset-top)) 16px auto; z-index: 10; display: flex; align-items: center; justify-content: space-between; gap: 12px; pointer-events: none; }
.connection-note { max-width: calc(100% - 244px); font-size: 12px; color: #cbd5e1; text-shadow: 0 1px 4px #000; }
.update-button { pointer-events: auto; min-height: 44px; padding: 4px 10px; color: #f3e8ff; background: #353148; border: 1px solid #b4a3c5; border-radius: 8px; font-size: 12px; }
.update-short { display: none; }
.motion-toggle { pointer-events: auto; margin-left: auto; flex-shrink: 0; min-height: 44px; padding: 0 12px; border: 1px solid #ffffff30; border-radius: 8px; background: #090b16df; color: #e2e8f0; font-size: 13px; }
.page-navigation { position: absolute; z-index: 10; bottom: max(12px, env(safe-area-inset-bottom)); left: 50%; transform: translateX(-50%); width: min(440px, calc(100% - 24px)); display: grid; grid-template-columns: 44px 1fr 44px; gap: 8px; padding: 6px; background: #0a0d18ed; border: 1px solid #ffffff26; border-radius: 16px; box-shadow: 0 6px 32px #0008; }
.page-tabs { display: grid; grid-template-columns: repeat(3, 1fr); gap: 4px; }
.page-navigation button { min-height: 44px; border: 0; border-radius: 10px; background: transparent; color: #cbd5e1; font-size: 15px; }
.page-navigation .arrow { font-size: 30px; line-height: 1; }
.page-navigation button[aria-current] { color: #fff; background: #353148; }
.page-navigation button:disabled { opacity: .35; cursor: default; }
.page-enter-active, .page-leave-active { transition: opacity .2s ease, transform .2s ease; }
.page-enter-from { opacity: 0; transform: translateY(12px); }
.page-leave-to { opacity: 0; transform: translateY(-12px); }
.reduced-motion .page-enter-active, .reduced-motion .page-leave-active { transition-duration: .01ms; }
@media (max-width: 360px) { .experience-tools { inset-inline: 12px; }.connection-note { display: none; }.update-full { display: none; }.update-short { display: inline; } }
</style>

