<script setup lang="ts">
// 跨端版本的独立 Canvas 2D 星空与 CSS 网格；不使用旧的 Three.js 背景。
import { onMounted, onUnmounted, ref, watch } from 'vue'
const props = withDefaults(defineProps<{ isActive: boolean; mode?: 'stars' | 'grid' }>(), { mode: 'stars' })
const canvas = ref<HTMLCanvasElement | null>(null)
let context: CanvasRenderingContext2D | null = null
let observer: ResizeObserver | undefined
let frame = 0
let last = 0
let width = 0
let height = 0
let phase = 0

function draw() {
  if (!context) return
  context.clearRect(0, 0, width, height)
  const count = Math.min(190, Math.floor(width * height / 4500))
  for (let i = 1; i <= count; i++) {
    const x = ((i * .61803398875) % 1) * width
    const y = ((i * .41421356237) % 1) * height
    const size = i % 9 === 0 ? 1.6 : .8
    context.globalAlpha = .25 + .45 * (1 + Math.sin(phase + i * 1.7)) / 2
    context.fillStyle = ['#c4b5fd', '#93c5fd', '#f9a8d4'][i % 3]!
    context.beginPath()
    context.arc(x, y, size, 0, Math.PI * 2)
    context.fill()
  }
  context.globalAlpha = 1
}
function tick(time: number) {
  if (time - last >= 32) { phase += .012; last = time; draw() }
  frame = requestAnimationFrame(tick)
}
function resize() {
  if (!canvas.value || !context) return
  width = canvas.value.clientWidth
  height = canvas.value.clientHeight
  const ratio = Math.min(1.5, window.devicePixelRatio || 1)
  canvas.value.width = Math.round(width * ratio)
  canvas.value.height = Math.round(height * ratio)
  context.setTransform(ratio, 0, 0, ratio, 0, 0)
  draw()
}
function sync() {
  cancelAnimationFrame(frame)
  if (props.isActive && props.mode === 'stars') frame = requestAnimationFrame(tick)
}
onMounted(() => {
  if (canvas.value) {
    context = canvas.value.getContext('2d')
    observer = new ResizeObserver(resize)
    observer.observe(canvas.value)
    resize()
    sync()
  }
})
watch(() => props.isActive, sync)
onUnmounted(() => { cancelAnimationFrame(frame); observer?.disconnect() })
</script>

<template>
  <div class="ambient" :class="mode" aria-hidden="true">
    <canvas v-if="mode === 'stars'" ref="canvas" />
    <div v-else class="grid-glow" :style="{ animationPlayState: isActive ? 'running' : 'paused' }" />
  </div>
</template>

<style scoped>
.ambient { position: absolute; inset: 0; pointer-events: none; overflow: hidden; background: #070812; }
.stars { background: radial-gradient(ellipse at 12% 18%, #42215b38, transparent 55%), radial-gradient(ellipse at 86% 78%, #1b426738, transparent 60%), #070812; }
canvas { width: 100%; height: 100%; display: block; }
.grid { background-image: linear-gradient(#8b79c30a 1px, transparent 1px), linear-gradient(90deg, #8b79c30a 1px, transparent 1px); background-size: 48px 48px; }
.grid-glow { position: absolute; inset: -30%; opacity: .6; background: radial-gradient(ellipse at 30% 60%, #326e5c48, transparent 45%), radial-gradient(ellipse at 75% 32%, #4f385848, transparent 45%); animation: drift 16s ease-in-out infinite alternate; }
@keyframes drift { to { transform: translate(8%, -4%); } }
</style>
