<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount, onUnmounted } from 'vue'
import GalaxyBackground from './GalaxyBackground.vue'
import type { GiftContent } from '../content'
import { storyPositionKey } from '../navigation'

const props = defineProps<{ isActive: boolean; gift: GiftContent }>()
defineEmits<{ next: [] }>()
const scrollRef = ref<HTMLDivElement | null>(null)
const chapterMenu = ref<HTMLDetailsElement | null>(null)
function savePosition() {
  try { localStorage.setItem(storyPositionKey(props.gift.id), String(scrollRef.value?.scrollTop ?? 0)) } catch { /* 禁用存储时只影响续读。 */ }
}
function jump(index: number) {
  if (chapterMenu.value) chapterMenu.value.open = false
  const chapter = scrollRef.value?.querySelectorAll<HTMLElement>('.chapter')[index]
  chapter?.scrollIntoView({ block: 'start' })
  chapter?.querySelector<HTMLElement>('h2')?.focus({ preventScroll: true })
}
onMounted(() => {
  try {
    const position = Number(localStorage.getItem(storyPositionKey(props.gift.id)))
    if (scrollRef.value && Number.isFinite(position) && position > 0) scrollRef.value.scrollTop = position
  } catch { /* 无存储权限时从开头阅读。 */ }
  window.addEventListener('pagehide', savePosition)
})
onBeforeUnmount(savePosition)
onUnmounted(() => {
  window.removeEventListener('pagehide', savePosition)
})
</script>

<template>
  <div class="story-page">
    <GalaxyBackground :is-active="isActive" />
    <div ref="scrollRef" class="story-scroll">
      <div class="story-content">

        <h1 class="story-main-title title-text" tabindex="-1">{{ gift.storyTitle }}</h1>
        <p class="story-epigraph">{{ gift.epigraph }}</p>
        <details ref="chapterMenu" class="chapter-menu">
          <summary>选择章节</summary>
          <div><button v-for="(chapter, index) in gift.chapters" :key="index" @click="jump(index)">{{ chapter.title }}</button></div>
        </details>

        <div v-for="(chapter, index) in gift.chapters" :key="index" class="chapter">
          <h2 class="chapter-title" tabindex="-1">{{ chapter.title }}</h2>
          <template v-for="(paragraph, p) in chapter.body.split(/\n+/).filter(Boolean)" :key="p">
            <p>{{ paragraph }}</p>
            <p v-if="chapter.closing && chapter.closingAfter !== undefined && p === Math.min(chapter.closingAfter, chapter.body.split(/\n+/).filter(Boolean).length - 1)" class="final-quote">{{ chapter.closing }}</p>
          </template>
          <p v-if="chapter.quote" class="quote">{{ chapter.quote }}</p>
          <p v-if="chapter.closing && chapter.closingAfter === undefined" class="final-quote">{{ chapter.closing }}</p>
        </div>

        <div class="story-end">
          <p class="end-text">—— 全文完 ——</p>
          <button class="next-story" @click="$emit('next')">收下人生寄语</button>
        </div>

      </div>
    </div>
  </div>
</template>

<style scoped>
.story-page {
  width: 100%;
  height: 100%;
  position: relative;
  overflow: hidden;
}

.story-scroll {
  top: max(68px, calc(env(safe-area-inset-top) + 60px));
  bottom: calc(84px + env(safe-area-inset-bottom));
  background: linear-gradient(90deg, transparent, #03071285 25%, #03071285 75%, transparent);
  position: absolute;
  z-index: 1;
  width: 100%;
  height: auto;
  overflow-y: auto;
  overscroll-behavior-y: contain;
  touch-action: pan-y pinch-zoom;
  scrollbar-width: thin;
  scrollbar-color: rgba(255,255,255,0.15) transparent;
}

.story-scroll::-webkit-scrollbar {
  width: 6px;
}

.story-scroll::-webkit-scrollbar-track {
  background: transparent;
}

.story-scroll::-webkit-scrollbar-thumb {
  background: rgba(255,255,255,0.15);
  border-radius: 3px;
}

.story-content {
  max-width: 680px;
  margin: 0 auto;
  padding: 24px 24px 40px;
}

.story-main-title {
  font-size: clamp(2.5rem, 6vw, 4rem);
  font-weight: 700;
  text-align: center;
  margin-bottom: 0.5rem;
  letter-spacing: 0.1em;
  overflow-wrap: anywhere;
}

.title-text {
  background-image:
    linear-gradient(110deg, transparent 0%, transparent 38%, rgba(255,255,255,0.85) 50%, transparent 62%, transparent 100%),
    linear-gradient(135deg, #38BDF8 0%, #A855F7 50%, #EC4899 100%);
  background-size: 250% 100%, 200% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: highlighterSweep 3.5s ease-in-out infinite, gradientFlow 5s ease infinite, cleanBreathe 3s ease-in-out infinite;
}

@keyframes highlighterSweep {
  0% { background-position: 200% 0, 0% 50%; }
  100% { background-position: -200% 0, 0% 50%; }
}

@keyframes gradientFlow {
  0% { background-position: 0% 50%, 0% 50%; }
  50% { background-position: 100% 50%, 100% 50%; }
  100% { background-position: 0% 50%, 0% 50%; }
}

@keyframes cleanBreathe {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.75; transform: scale(0.995); }
}

.story-epigraph {
  text-align: center;
  color: #b9bdcd;
  font-size: 1rem;
  font-style: italic;
  margin-bottom: 2rem;
}

.chapter {
  margin-bottom: 3.5rem;
  scroll-margin-top: 24px;
}

.chapter-title {
  font-size: clamp(1.3rem, 3vw, 1.8rem);
  font-weight: 600;
  color: #c084fc;
  margin-bottom: 1.2rem;
  padding-bottom: 0.5rem;
  border-bottom: 1px solid rgba(168, 85, 247, 0.2);
}

.chapter p {
  font-size: clamp(0.95rem, 1.8vw, 1.1rem);
  line-height: 1.9;
  color: rgba(255,255,255,0.75);
  margin-bottom: 1rem;
  text-indent: 2em;
}

.quote {
  font-style: italic;
  color: #f18cbe !important;
  text-indent: 0 !important;
  padding-left: 1.5rem;
  border-left: 3px solid rgba(236, 72, 153, 0.4);
  margin-top: 1.5rem !important;
  margin-bottom: 2rem !important;
}

.final-quote {
  font-size: clamp(1.2rem, 2.5vw, 1.6rem) !important;
  color: #F8FAFC !important;
  text-indent: 0 !important;
  text-align: center;
  font-weight: 600;
  padding: 2rem 0;
}

.story-end {
  text-align: center;
  padding: 3rem 0;
}

.end-text {
  color: #b9bdcd;
  font-size: 1rem;
  letter-spacing: 0.3em;
}
.chapter-menu { margin-bottom: 32px; color: #d5d9e8; border: 1px solid #ffffff24; border-radius: 8px; background: #0e1023da; }
.chapter-menu summary { min-height: 48px; padding: 12px 16px; cursor: pointer; }
.chapter-menu > div { display: grid; padding: 0 8px 8px; }
.chapter-menu button { min-height: 44px; padding: 8px; color: #e2e8f0; background: transparent; border: 0; text-align: left; }
.next-story { min-height: 48px; padding: 12px 24px; margin-top: 24px; color: #f4eafa; background: #2c203b; border: 1px solid #9676ba; border-radius: 8px; }
@media (max-width: 480px) { .story-content { padding-inline: 20px; }.story-main-title { font-size: 36px; }.story-epigraph { font-size: 14px; line-height: 1.7; }.chapter p { font-size: 16px; } }
</style>
