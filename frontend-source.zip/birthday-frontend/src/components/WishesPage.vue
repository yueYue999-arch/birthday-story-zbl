<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import WishLightBackground from './WishLightBackground.vue'
import type { GiftContent } from '../content'

defineProps<{ isActive: boolean; gift: GiftContent }>()
defineEmits<{ restart: [] }>()
const lit = ref(false)
const visible = ref(false)
let entranceTimer: ReturnType<typeof setTimeout>
onMounted(() => { entranceTimer = setTimeout(() => { visible.value = true }, 100) })
onUnmounted(() => clearTimeout(entranceTimer))
const numerals = ["壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖", "拾", "拾壹", "拾贰"]
</script>

<template>
  <div class="wishes-page">
    <WishLightBackground :is-active="isActive" :lit="lit" />

    <div class="wishes-scroll">
      <div class="wishes-content" :class="{ lit, visible }">
        <h1 class="wishes-title" tabindex="-1">{{ gift.wishesTitle }}</h1>

        <div class="wishes-list">
          <div v-for="(wish, index) in gift.wishes" :key="index" class="wish-item">
            <span class="wish-num">{{ numerals[index] }}</span>
            <p class="wish-text">{{ wish }}</p>
          </div>
        </div>

        <div class="final-blessing">
          <p class="blessing-main">{{ gift.blessing }}</p>
          <p class="blessing-sign">{{ gift.signature }}</p>
          <button class="light-button" :aria-pressed="lit" @click="lit = !lit">{{ lit ? '祝福已点亮 ✦' : '点亮这份祝福' }}</button>
          <button class="restart-button" @click="$emit('restart')">重看开场</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.wishes-page {
  width: 100%;
  height: 100%;
  position: relative;
  overflow: hidden;
  background: #100d1b;
}

.wishes-scroll {
  top: max(68px, calc(env(safe-area-inset-top) + 60px));
  bottom: calc(84px + env(safe-area-inset-bottom));
  position: absolute;
  left: 0;
  right: 0;
  z-index: 1;
  overflow-y: auto;
  overscroll-behavior-y: contain;
  touch-action: pan-y pinch-zoom;
  scrollbar-width: thin;
  scrollbar-color: rgba(255,255,255,0.15) transparent;
}

.wishes-scroll::-webkit-scrollbar {
  width: 6px;
}

.wishes-scroll::-webkit-scrollbar-thumb {
  background: rgba(255,255,255,0.15);
  border-radius: 3px;
}

.wishes-content {
  position: relative;
  min-height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 24px 24px 40px;
  opacity: 0;
  transform: translateY(30px);
  overflow-wrap: anywhere;
  transition: opacity 1.2s cubic-bezier(0.16, 1, 0.3, 1), transform 1.2s cubic-bezier(0.16, 1, 0.3, 1);
}

.wishes-content.visible {
  opacity: 1;
  transform: translateY(0);
}

.wishes-title {
  font-size: clamp(2rem, 5vw, 3.5rem);
  font-weight: 700;
  color: #F8FAFC;
  margin-bottom: 3rem;
  letter-spacing: 0.15em;
}

.wishes-list {
  display: flex;
  flex-direction: column;
  gap: 1.8rem;
  max-width: 600px;
  margin-bottom: 3.5rem;
}

.wish-item {
  display: flex;
  align-items: flex-start;
  gap: 1.2rem;
}

.wish-num {
  font-size: 1.5rem;
  color: #c084fc;
  font-weight: 600;
  min-width: 2rem;
  text-align: center;
  line-height: 1.8;
}

.wish-text {
  font-size: clamp(0.95rem, 1.8vw, 1.1rem);
  line-height: 1.8;
  color: #e3e3eb;
  text-shadow: 0 1px 4px #000, 0 0 10px #000;
}

.final-blessing {
  text-align: center;
  padding-top: 1rem;
  border-top: 1px solid rgba(255,255,255,0.08);
}

.blessing-main {
  font-size: clamp(1.5rem, 3.5vw, 2.2rem);
  font-weight: 700;
  color: #f3acd3;
  margin-bottom: 1.2rem;
}

.blessing-sub {
  font-size: clamp(0.9rem, 1.6vw, 1.05rem);
  color: rgba(255,255,255,0.55);
  line-height: 2;
}

.blessing-sign {
  margin-top: 2rem;
  font-size: 0.9rem;
  color: #b9bdcd;
  font-style: italic;
}
.light-button, .restart-button { display: block; min-height: 48px; margin: 24px auto 0; padding: 10px 20px; border-radius: 8px; border: 1px solid #8a6485; background: #261d2e; color: #fff; }
.restart-button { background: transparent; border-color: transparent; font-size: 14px; color: #c1c5d3; margin-top: 8px; }
.lit .blessing-main { color: #fff4d7; text-shadow: 0 0 24px #ffbb6570; }
.light-button[aria-pressed='true'] { background: #493329; border-color: #cda075; }
@media (max-width: 480px) { .wish-item { gap: 12px; }.wishes-title { font-size: 32px; margin-bottom: 32px; }.wishes-list { margin-bottom: 36px; }.wish-text { font-size: 16px; } }
</style>
