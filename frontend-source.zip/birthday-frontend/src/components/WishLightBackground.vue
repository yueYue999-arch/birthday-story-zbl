<script setup lang="ts">
// Original implementation for this gift, 2026-09-20. GPL-3.0 as part of this frontend.
import { onMounted, onUnmounted, ref, watch } from 'vue'

const props = defineProps<{ isActive: boolean; lit: boolean }>()
const canvasRef = ref<HTMLCanvasElement | null>(null)
let sync = () => {}
let illuminate = () => {}
let cleanup = () => {}
watch(() => props.isActive, () => sync())
watch(() => props.lit, () => illuminate())
onUnmounted(() => cleanup())

onMounted(() => {
  const canvas = canvasRef.value!
  const ctx = canvas.getContext('2d')
  if (!ctx) return // The CSS halo remains visible if canvas is unavailable.
  let width = 1, height = 1, dpr = 1
  let frame = 0, previous = 0, time = 0, pulse = 10
  const interval = window.matchMedia('(pointer: coarse)').matches ? 1000 / 30 : 1000 / 60
  // Stable seeds avoid the visual jump of randomizing on rotation or resize.
  const lights = Array.from({ length: 48 }, (_, i) => ({
    x: (i * 0.61803398875) % 1,
    y: (i * 0.41421356237) % 1,
    size: 0.8 + (i % 4) * 0.35,
    speed: 0.009 + (i % 5) * 0.0018,
    phase: i * 2.399963,
  }))
  function draw() {
    ctx!.setTransform(dpr, 0, 0, dpr, 0, 0)
    ctx!.clearRect(0, 0, width, height)
    const count = width < 600 ? 30 : 48
    for (let i = 0; i < count; i++) {
      const light = lights[i]!
      const x = (light.x + Math.sin(time * 0.2 + light.phase) * 0.035) * width
      const y = (1 - ((light.y + time * light.speed) % 1)) * (height + 60) - 30
      const edge = Math.min(1, Math.max(0, Math.min(y, height - y) / 70))
      const breath = (0.3 + (Math.sin(time * 0.65 + light.phase) + 1) * 0.18) * edge
      const tint = props.lit ? '255,217,156' : i % 3 === 0 ? '238,168,202' : '195,182,236'
      const radius = light.size * (props.lit ? 1.3 : 1)
      const glow = ctx!.createRadialGradient(x, y, 0, x, y, radius * 8)
      glow.addColorStop(0, `rgba(${tint},${breath * 0.48})`)
      glow.addColorStop(1, `rgba(${tint},0)`)
      ctx!.fillStyle = glow
      ctx!.fillRect(x - radius * 8, y - radius * 8, radius * 16, radius * 16)
      ctx!.fillStyle = `rgba(${tint},${breath})`
      ctx!.beginPath(); ctx!.arc(x, y, radius, 0, Math.PI * 2); ctx!.fill()
    }
    // A single, gentle ring answers the explicit “light this blessing” button.
    // Swipes, taps on text and mouse movement never drive the background.
    if (props.lit && pulse < 3) {
      const progress = pulse / 3
      const radius = 24 + Math.min(width, height) * 0.8 * (1 - Math.pow(1 - progress, 2))
      ctx!.strokeStyle = `rgba(255,218,169,${(1 - progress) * 0.4})`
      ctx!.lineWidth = 1.5
      ctx!.beginPath(); ctx!.ellipse(width / 2, height * 0.68, radius, radius * 0.65, 0, 0, Math.PI * 2); ctx!.stroke()
    }
  }
  function animate(timestamp: number) {
    if (!props.isActive) return
    if (!previous || timestamp - previous >= interval - 1) {
      const elapsed = previous ? Math.min((timestamp - previous) / 1000, 0.08) : 0
      previous = timestamp
      time += elapsed
      pulse += elapsed
      draw()
    }
    frame = requestAnimationFrame(animate)
  }
  sync = () => {
    cancelAnimationFrame(frame)
    previous = 0
    if (props.isActive) frame = requestAnimationFrame(animate)
    else draw()
  }
  illuminate = () => {
    pulse = props.isActive && props.lit ? 0 : 10
    draw()
  }
  const resize = () => {
    const rect = canvas.getBoundingClientRect()
    width = Math.max(1, rect.width); height = Math.max(1, rect.height)
    dpr = Math.min(window.devicePixelRatio || 1, 1.5)
    canvas.width = Math.round(width * dpr); canvas.height = Math.round(height * dpr)
    draw()
  }
  const observer = new ResizeObserver(resize)
  observer.observe(canvas)
  window.addEventListener('resize', resize)
  resize()
  sync()
  cleanup = () => {
    cancelAnimationFrame(frame)
    observer.disconnect()
    window.removeEventListener('resize', resize)
  }
})
</script>

<template>
  <div class="wish-lights" :class="{ lit }" aria-hidden="true">
    <div class="halo halo-rose" />
    <div class="halo halo-gold" />
    <canvas ref="canvasRef" class="wish-light-canvas" />
    <div class="reading-shade" />
  </div>
</template>

<style scoped>
.wish-lights, .wish-light-canvas, .reading-shade { position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none; }
.wish-lights { overflow: hidden; background: linear-gradient(160deg, #181122, #0d0d19 55%, #17101d); }
.halo { position: absolute; width: 130%; height: 85%; left: -15%; pointer-events: none; }
.halo-rose { bottom: -36%; background: radial-gradient(ellipse, #b2648930, transparent 65%); }
.halo-gold { bottom: -22%; opacity: 0; background: radial-gradient(ellipse, #f2be6c36, transparent 66%); transition: opacity 1.8s ease; }
.lit .halo-gold { opacity: 1; }
.reading-shade { background: radial-gradient(ellipse at 50% 40%, #0d0d194d, transparent 76%); }
</style>
