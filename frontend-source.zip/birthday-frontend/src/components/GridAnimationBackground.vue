<script setup lang="ts">
// Adapted from SimonAKing/HomePage/src/js/main.js, LGPL-3.0.
// Modified 2026-09-20: touch pointers, logical pixel sizes, bounded DPR and animation lifecycle.
import { ref, onMounted, onUnmounted, watch } from 'vue'

const props = defineProps<{ isActive: boolean }>()

const canvasRef = ref<HTMLCanvasElement | null>(null)
let gridAnim: GridAnimation | null = null

class GridAnimation {
  canvas: HTMLCanvasElement
  ctx: CanvasRenderingContext2D
  options: any
  gridOffset = { x: 0, y: 0 }
  hoveredSquare: { x: number; y: number } | null = null
  animationFrame: number | null = null
  currentOpacity = 0
  targetOpacity = 0
  lastTimestamp = 0
  trailSquares = new Map<string, { x: number; y: number; opacity: number }>()
  specialBlock: { x: number; y: number; color: string } | null = null
  snakeBody: { x: number; y: number }[] = []
  shouldGrow = false
  isPhone: boolean
  running = false
  width = 0
  height = 0
  dpr = 1
  observer: ResizeObserver | null = null
  onMouseMove = (e: PointerEvent) => this.handleMouseMove(e)
  onMouseLeave = () => { this.hoveredSquare = null; this.targetOpacity = 0 }
  onResize = () => this.resizeCanvas()

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas
    this.ctx = canvas.getContext('2d')!
    this.isPhone = window.matchMedia('(pointer: coarse)').matches
    this.options = {
      direction: 'diagonal',
      speed: this.isPhone ? 0.03 : 0.05,
      borderColor: this.isPhone ? 'rgba(255, 255, 255, 0.2)' : 'rgba(255, 255, 255, 0.1)',
      squareSize: this.isPhone ? 50 : 40,
      hoverFillColor: 'rgba(255, 255, 255, 0.8)',
      hoverShadowColor: 'rgba(255, 255, 255, 0.8)',
      transitionDuration: 200,
      trailDuration: this.isPhone ? 2000 : 1500,
      specialBlockColor: 'rgba(100, 255, 152, 0.8)',
      snakeHeadColor: 'rgba(255, 255, 255, 0.95)',
      snakeTailColor: 'rgba(218, 231, 255, 0.25)',
      snakeColorDecay: 0.85,
    }
  }

  init() {
    this.resizeCanvas()
    this.setupEvents()
    this.createSpecialBlock()
    this.drawGrid()
  }

  start() {
    if (this.running) return
    this.running = true
    this.lastTimestamp = 0
    this.animate()
  }

  stop() {
    this.running = false
    if (this.animationFrame) { cancelAnimationFrame(this.animationFrame); this.animationFrame = null }
  }

  resetOffset() {
    this.gridOffset = { x: 0, y: 0 }
    this.hoveredSquare = null
    this.snakeBody = []
    this.trailSquares.clear()
    this.currentOpacity = 0
    this.targetOpacity = 0
    this.createSpecialBlock()
  }

  resizeCanvas() {
    this.dpr = Math.min(window.devicePixelRatio || 1, 2)
    const rect = this.canvas.getBoundingClientRect()
    this.width = rect.width; this.height = rect.height
    this.canvas.width = Math.round(this.width * this.dpr)
    this.canvas.height = Math.round(this.height * this.dpr)
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0)
    this.snakeBody = []
    this.createSpecialBlock()
    this.drawGrid()
  }

  setupEvents() {
    const host = this.canvas.parentElement!
    host.addEventListener('pointermove', this.onMouseMove, { passive: true })
    host.addEventListener('pointerdown', this.onMouseMove, { passive: true })
    host.addEventListener('pointerleave', this.onMouseLeave)
    this.observer = new ResizeObserver(this.onResize)
    this.observer.observe(host)
    window.addEventListener('resize', this.onResize)
  }

  handleMouseMove(e: PointerEvent) {
    const rect = this.canvas.getBoundingClientRect()
    const mx = e.clientX - rect.left, my = e.clientY - rect.top
    const sx = Math.floor(this.gridOffset.x / this.options.squareSize) * this.options.squareSize
    const sy = Math.floor(this.gridOffset.y / this.options.squareSize) * this.options.squareSize
    const gx = Math.floor((mx + this.gridOffset.x - sx) / this.options.squareSize)
    const gy = Math.floor((my + this.gridOffset.y - sy) / this.options.squareSize)

    if (this.hoveredSquare?.x !== gx || this.hoveredSquare?.y !== gy) {
      if (this.hoveredSquare) {
        this.snakeBody.unshift({ x: this.hoveredSquare.x, y: this.hoveredSquare.y })
        if (!this.shouldGrow && this.snakeBody.length > 0) this.snakeBody.pop()
        this.shouldGrow = false
      }
      this.hoveredSquare = { x: gx, y: gy }
      this.targetOpacity = 0.6
      if (this.specialBlock && gx === this.specialBlock.x && gy === this.specialBlock.y) {
        this.shouldGrow = true
        this.createSpecialBlock()
      }
    }
    if (!this.running) this.drawGrid()
  }

  createSpecialBlock() {
    const nx = Math.max(1, Math.ceil(this.width / this.options.squareSize) - 2)
    const ny = Math.max(1, Math.ceil(this.height / this.options.squareSize) - 2)
    // Choose from free cells; the original retry loop could hang on a full board.
    const free = []
    for (let x = 1; x <= nx; x++) for (let y = 1; y <= ny; y++) {
      if (!this.snakeBody.some(s => s.x === x && s.y === y)
        && !(this.hoveredSquare?.x === x && this.hoveredSquare?.y === y)) free.push({ x, y })
    }
    const cell = free[Math.floor(Math.random() * free.length)]
    this.specialBlock = cell ? { ...cell, color: this.options.specialBlockColor } : null
  }

  drawGrid() {
    const dpr = this.dpr
    this.ctx.setTransform(1, 0, 0, 1, 0, 0)
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height)
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0)

    const sx = Math.floor(this.gridOffset.x / this.options.squareSize) * this.options.squareSize
    const sy = Math.floor(this.gridOffset.y / this.options.squareSize) * this.options.squareSize

    this.snakeBody.forEach((seg, i) => {
      const sqx = Math.round(seg.x * this.options.squareSize + sx - (this.gridOffset.x % this.options.squareSize))
      const sqy = Math.round(seg.y * this.options.squareSize + sy - (this.gridOffset.y % this.options.squareSize))
      this.ctx.shadowColor = this.options.hoverShadowColor
      this.ctx.shadowBlur = 15
      if (i === 0) {
        this.ctx.fillStyle = this.options.snakeHeadColor
      } else {
        const f = Math.pow(this.options.snakeColorDecay, i)
        const hc = this.parseColor(this.options.snakeHeadColor)
        const tc = this.parseColor(this.options.snakeTailColor)
        const r = Math.round(hc.r + (tc.r - hc.r) * (1 - f))
        const g = Math.round(hc.g + (tc.g - hc.g) * (1 - f))
        const b = Math.round(hc.b + (tc.b - hc.b) * (1 - f))
        const a = hc.a + (tc.a - hc.a) * (1 - f)
        this.ctx.fillStyle = `rgba(${r},${g},${b},${a})`
      }
      this.ctx.fillRect(sqx, sqy, this.options.squareSize, this.options.squareSize)
      this.ctx.shadowColor = 'transparent'; this.ctx.shadowBlur = 0
    })

    for (let x = sx; x < this.width + this.options.squareSize; x += this.options.squareSize) {
      for (let y = sy; y < this.height + this.options.squareSize; y += this.options.squareSize) {
        const sqx = Math.round(x - (this.gridOffset.x % this.options.squareSize))
        const sqy = Math.round(y - (this.gridOffset.y % this.options.squareSize))
        const gx = Math.floor((x - sx) / this.options.squareSize)
        const gy = Math.floor((y - sy) / this.options.squareSize)

        if (this.specialBlock && gx === this.specialBlock.x && gy === this.specialBlock.y) {
          this.ctx.shadowColor = 'rgba(255,255,255,0.5)'; this.ctx.shadowBlur = 20
          this.ctx.fillStyle = this.specialBlock.color
          this.ctx.fillRect(sqx, sqy, this.options.squareSize, this.options.squareSize)
          this.ctx.shadowColor = 'transparent'; this.ctx.shadowBlur = 0
        }

        if (this.hoveredSquare && gx === this.hoveredSquare.x && gy === this.hoveredSquare.y) {
          this.ctx.shadowColor = this.options.hoverShadowColor; this.ctx.shadowBlur = 15
          this.ctx.fillStyle = this.options.hoverFillColor
          this.ctx.fillRect(sqx, sqy, this.options.squareSize, this.options.squareSize)
          this.ctx.shadowColor = 'transparent'; this.ctx.shadowBlur = 0
        }

        this.ctx.strokeStyle = this.options.borderColor
        this.ctx.strokeRect(sqx, sqy, this.options.squareSize, this.options.squareSize)
      }
    }

    const grd = this.ctx.createRadialGradient(this.canvas.width / dpr / 2, this.canvas.height / dpr / 2, 0, this.canvas.width / dpr / 2, this.canvas.height / dpr / 2, Math.sqrt(Math.pow(this.canvas.width / dpr, 2) + Math.pow(this.canvas.height / dpr, 2)) / 2)
    grd.addColorStop(0, 'rgba(6,6,6,0)'); grd.addColorStop(1, '#060606')
    this.ctx.fillStyle = grd
    this.ctx.fillRect(0, 0, this.canvas.width / dpr, this.canvas.height / dpr)
  }

  parseColor(str: string) {
    const m = str.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([.\d]+))?\)/)
    if (!m) return { r: 255, g: 255, b: 255, a: 1 }
    return { r: +m[1]!, g: +m[2]!, b: +m[3]!, a: m[4] ? parseFloat(m[4]) : 1 }
  }

  updateAnimation(ts: number) {
    if (!this.running) return
    if (!this.lastTimestamp) this.lastTimestamp = ts
    const dt = Math.min(ts - this.lastTimestamp, 50); this.lastTimestamp = ts

    if (this.currentOpacity !== this.targetOpacity) {
      const p = Math.min(dt / this.options.transitionDuration, 1)
      this.currentOpacity += (this.targetOpacity - this.currentOpacity) * p
    }

    for (const [k, sq] of this.trailSquares) {
      sq.opacity -= dt / this.options.trailDuration
      if (sq.opacity <= 0) this.trailSquares.delete(k)
    }

    const spd = this.options.speed * dt / (1000 / 60)
    switch (this.options.direction) {
      case 'diagonal':
        this.gridOffset.x = (this.gridOffset.x - spd + this.options.squareSize) % this.options.squareSize
        this.gridOffset.y = (this.gridOffset.y - spd + this.options.squareSize) % this.options.squareSize
        break
    }

    this.drawGrid()
    this.animationFrame = requestAnimationFrame((t) => this.updateAnimation(t))
  }

  animate() {
    this.animationFrame = requestAnimationFrame((t) => this.updateAnimation(t))
  }

  destroy() {
    this.stop()
    const host = this.canvas.parentElement!
    host.removeEventListener('pointermove', this.onMouseMove)
    host.removeEventListener('pointerdown', this.onMouseMove)
    host.removeEventListener('pointerleave', this.onMouseLeave)
    this.observer?.disconnect()
    window.removeEventListener('resize', this.onResize)
  }
}

onMounted(() => {
  if (canvasRef.value) {
    gridAnim = new GridAnimation(canvasRef.value)
    gridAnim.init()
    if (props.isActive) gridAnim.start()
  }
})

watch(() => props.isActive, (active) => {
  if (!gridAnim) return
  if (active) {
    gridAnim.start()
  } else {
    gridAnim.stop()
  }
})

onUnmounted(() => {
  gridAnim?.destroy()
})
</script>

<template>
  <canvas ref="canvasRef" class="grid-canvas" aria-hidden="true" />
</template>

<style scoped>
.grid-canvas {
  pointer-events: none;
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  z-index: 0;
}
</style>
