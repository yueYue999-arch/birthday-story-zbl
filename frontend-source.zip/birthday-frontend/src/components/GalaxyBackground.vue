<script setup lang="ts">
// @ts-nocheck
// Adapted from FrankWkd-Plus/galaxy-theme-portfolio (GPL-3.0).
// Modified 2026-09-20: non-interactive ambient motion, resize, bounded DPR and cleanup.
import { ref, onMounted, onUnmounted, watch } from 'vue'
import AmbientBackground from './AmbientBackground.vue'
import * as THREE from 'three'

const props = defineProps<{ isActive?: boolean }>()

let animId: number | null = null
const containerRef = ref<HTMLDivElement | null>(null)
const unavailable = ref(false)
let animRunning = false
let syncActive = () => {}
let cleanup = () => {}
watch(() => props.isActive, () => syncActive())
onUnmounted(() => cleanup())

onMounted(() => {
  const container = containerRef.value
  if (!container) return

  const canvas = document.createElement('canvas')
  container.appendChild(canvas)

  const scene = new THREE.Scene()
  const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
  let renderer: THREE.WebGLRenderer
  try { renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true }) }
  catch { unavailable.value = true; canvas.remove(); return }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5))
  camera.position.z = 5

  const COUNT = 5000
  const geo = new THREE.BufferGeometry()
  const posArr = new Float32Array(COUNT * 3)
  const colorArr = new Float32Array(COUNT * 3)
  const baseColorArr = new Float32Array(COUNT * 3)
  const phaseArr = new Float32Array(COUNT)
  const speedArr = new Float32Array(COUNT)

  const defaultColors = [[0.66, 0.33, 0.97], [0.93, 0.28, 0.60], [0.23, 0.51, 0.96]]

  for (let i = 0; i < COUNT; i++) {
    const i3 = i * 3
    posArr[i3] = (Math.random() - 0.5) * 100
    posArr[i3 + 1] = (Math.random() - 0.5) * 100
    posArr[i3 + 2] = (Math.random() - 0.5) * 100
    const pick = defaultColors[Math.floor(Math.random() * defaultColors.length)]!
    baseColorArr[i3] = pick[0]; baseColorArr[i3 + 1] = pick[1]; baseColorArr[i3 + 2] = pick[2]
    colorArr[i3] = pick[0]; colorArr[i3 + 1] = pick[1]; colorArr[i3 + 2] = pick[2]
    phaseArr[i] = Math.random() * Math.PI * 2
    speedArr[i] = Math.random() < 0.15 ? 2.5 + Math.random() * 3.5 : 0.6 + Math.random() * 1.4
  }

  geo.setAttribute('position', new THREE.BufferAttribute(posArr, 3))
  geo.setAttribute('color', new THREE.BufferAttribute(colorArr, 3))

  const glowCanvas = document.createElement('canvas'); glowCanvas.width = 64; glowCanvas.height = 64
  const glowCtx = glowCanvas.getContext('2d')!
  const grad = glowCtx.createRadialGradient(32, 32, 0, 32, 32, 32)
  grad.addColorStop(0, 'rgba(255,255,255,1)'); grad.addColorStop(0.2, 'rgba(255,255,255,0.85)')
  grad.addColorStop(0.5, 'rgba(255,255,255,0.35)'); grad.addColorStop(1, 'rgba(255,255,255,0)')
  glowCtx.fillStyle = grad; glowCtx.fillRect(0, 0, 64, 64)
  const glowTex = new THREE.CanvasTexture(glowCanvas)

  const mat = new THREE.PointsMaterial({ size: 0.45, map: glowTex, vertexColors: true, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false })
  const particlesMesh = new THREE.Points(geo, mat)
  scene.add(particlesMesh)

  const t1 = new THREE.Mesh(new THREE.TorusGeometry(10, 3, 16, 100), new THREE.MeshBasicMaterial({ color: 0xa855f7, wireframe: true, transparent: true, opacity: 0.3 }))
  scene.add(t1)
  const t2 = new THREE.Mesh(new THREE.TorusGeometry(15, 2, 16, 100), new THREE.MeshBasicMaterial({ color: 0xec4899, wireframe: true, transparent: true, opacity: 0.2 }))
  t2.rotation.x = Math.PI / 4; scene.add(t2)

  let time = 0
  let previous = 0
  const frameInterval = window.matchMedia('(pointer: coarse)').matches ? 1000 / 30 : 1000 / 60
  const onResize = () => {
    const { width, height } = container.getBoundingClientRect()
    if (!width || !height) return
    camera.aspect = width / height
    camera.updateProjectionMatrix()
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5))
    renderer.setSize(width, height)
    if (!unavailable.value) render(0)
  }
  const resizeObserver = new ResizeObserver(onResize)
  resizeObserver.observe(container)
  window.addEventListener('resize', onResize)

  function render(step: number) {
    time += 0.003 * step
    const cols = geo.attributes.color.array as Float32Array
    for (let i = 0; i < COUNT; i++) {
      const i3 = i * 3
      const breath = 0.2 + 1.1 * (Math.sin(time * 3.0 * speedArr[i]! + phaseArr[i]!) * 0.5 + 0.5)
      cols[i3] = baseColorArr[i3]! * breath
      cols[i3 + 1] = baseColorArr[i3 + 1]! * breath
      cols[i3 + 2] = baseColorArr[i3 + 2]! * breath
    }
    geo.attributes.color.needsUpdate = true
    particlesMesh.rotation.y = time * 0.1
    particlesMesh.rotation.x = Math.sin(time * 0.3) * 0.05
    t1.rotation.x += 0.0022 * step; t1.rotation.y += 0.0012 * step; t1.rotation.z += 0.0007 * step
    t2.rotation.x += 0.0008 * step; t2.rotation.y += 0.0018 * step; t2.rotation.z += 0.0005 * step
    camera.lookAt(scene.position)
    renderer.render(scene, camera)
  }
  function animate(timestamp: number) {
    if (!animRunning || unavailable.value) return
    if (previous && timestamp - previous < frameInterval - 1) {
      animId = requestAnimationFrame(animate)
      return
    }
    const step = previous ? Math.min((timestamp - previous) / (1000 / 60), 3) : 1
    previous = timestamp
    render(step)
    animId = requestAnimationFrame(animate)
  }
  syncActive = () => {
    if (animId !== null) cancelAnimationFrame(animId)
    animId = null
    previous = 0
    animRunning = props.isActive !== false && !unavailable.value
    if (animRunning) animId = requestAnimationFrame(animate)
  }
  const onContextLost = (event: Event) => {
    event.preventDefault()
    unavailable.value = true
    syncActive()
  }
  canvas.addEventListener('webglcontextlost', onContextLost)
  onResize()
  syncActive()
  cleanup = () => {
    animRunning = false
    if (animId !== null) cancelAnimationFrame(animId)
    window.removeEventListener('resize', onResize)
    resizeObserver.disconnect()
    canvas.removeEventListener('webglcontextlost', onContextLost)
    glowTex.dispose(); geo.dispose(); mat.dispose()
    t1.geometry.dispose(); t1.material.dispose()
    t2.geometry.dispose(); t2.material.dispose()
    renderer.dispose()
    renderer.forceContextLoss()
    canvas.remove()
  }
})
</script>

<template>
  <div ref="containerRef" class="galaxy-bg" aria-hidden="true" :data-renderer="unavailable ? 'fallback' : 'webgl'">
    <AmbientBackground v-if="unavailable" :is-active="isActive !== false" />
    <div v-if="unavailable" class="fallback-rings" />
  </div>
</template>

<style scoped>
.fallback-rings { position: absolute; inset: 15% -15%; border: 2px solid #a855f775; border-radius: 50%; transform: rotate(-35deg); box-shadow: 0 0 18px #a855f740, inset 0 0 18px #ec489940; }
.fallback-rings::after { content: ""; position: absolute; inset: 15% -10%; border: 1px solid #ec489955; border-radius: 50%; transform: rotate(65deg); }
.galaxy-bg {
  pointer-events: none;
  position: absolute;
  inset: 0;
  z-index: 0;
  background: #030712;
}

.galaxy-bg :deep(canvas) {
  position: absolute;
  inset: 0;
  width: 100% !important;
  height: 100% !important;
}
</style>
