<script setup lang="ts">
// @ts-nocheck
// Adapted from Pavel Dobryakov's MIT WebGL Fluid Simulation via SimonAKing/HomePage.
// Cross-device input, bounded GPU resources and lifecycle fixes: 2026-09-20.
// See public/third-party-notices.txt for attribution and the MIT license.
import { ref, onMounted, onUnmounted, watch } from 'vue'

const props = defineProps<{ isActive?: boolean }>()

const emit = defineEmits<{ interact: [] }>()
const canvasRef = ref<HTMLCanvasElement | null>(null)
const failed = ref(false)
const glow = ref({ x: 50, y: 50 })
function touchGlow(event: PointerEvent) {
  if (event.type === 'pointermove' && !event.buttons && event.pointerType === 'mouse') return
  const bounds = (event.currentTarget as HTMLElement).getBoundingClientRect()
  glow.value = { x: (event.clientX - bounds.left) / bounds.width * 100, y: (event.clientY - bounds.top) / bounds.height * 100 }
  if (event.type === 'pointerdown') emit('interact')
}
function contextLost() {
  failed.value = true
  fluidControls?.cleanup()
  fluidControls = null
}
let animationId: number | null = null
let fluidControls: { cleanup: () => void; pause: () => void; resume: () => void } | null = null

onMounted(() => {
  if (!canvasRef.value) return
  try {
    fluidControls = initFluidSimulation(canvasRef.value)
    failed.value = !fluidControls
    if (props.isActive === false) fluidControls?.pause()
  } catch (error) {
    failed.value = true
    const gl = canvasRef.value.getContext('webgl2') || canvasRef.value.getContext('webgl')
    gl?.getExtension('WEBGL_lose_context')?.loseContext()
    console.warn('流体效果不可用，已使用可互动的柔光背景。', error)
  }
})

watch(() => props.isActive, (active) => {
  if (!fluidControls) return
  if (active) fluidControls.resume()
  else fluidControls.pause()
})

onUnmounted(() => {
  if (animationId) cancelAnimationFrame(animationId)
  fluidControls?.cleanup()
})

function initFluidSimulation(canvas: HTMLCanvasElement) {
  const coarse = matchMedia('(pointer: coarse)').matches
  const pixelRatio = Math.min(window.devicePixelRatio || 1, 1.5)
  const config = {
    SIM_RESOLUTION: coarse ? 64 : 128,
    DYE_RESOLUTION: coarse ? 256 : 512,
    BLOOM_RESOLUTION: 256,
    BLOOM_ITERATIONS: 8,
    BLOOM_SOFT_KNEE: 0.7,
    BLOOM_THRESHOLD: 0.6,
    BLOOM_INTENSITY: 0.3,
    SUNRAYS_RESOLUTION: 196,
    SUNRAYS_WEIGHT: 0.3,
    DENSITY_DISSIPATION: 0.97,
    VELOCITY_DISSIPATION: 0.1,
    PRESSURE: 0.8,
    PRESSURE_ITERATIONS: coarse ? 12 : 16,
    CURL: 50,
    SPLAT_RADIUS: 0.35,
    SPLAT_FORCE: 10000,
    SHADING: true,
    COLORFUL: true,
    COLOR_UPDATE_SPEED: 15,
    PAUSED: false,
    BACK_COLOR: { r: 30, g: 31, b: 33 },
    TRANSPARENT: false,
  }

  function pointerPrototype() {
    return { id: -1, texcoordX: 0, texcoordY: 0, prevTexcoordX: 0, prevTexcoordY: 0, deltaX: 0, deltaY: 0, down: false, moved: false, color: generateColor() }
  }

  const pointers: ReturnType<typeof pointerPrototype>[] = [pointerPrototype()]
  const splatStack: number[] = []
  let lastUpdateTime = Date.now()
  let colorUpdateTimer = 0

  const gl = canvas.getContext('webgl2', { alpha: true, depth: false, stencil: false, antialias: false, preserveDrawingBuffer: false }) || canvas.getContext('webgl', { alpha: true, depth: false, stencil: false, antialias: false, preserveDrawingBuffer: false })
  if (!gl) return null

  const isWebGL2 = (gl as WebGL2RenderingContext).constructor?.name === 'WebGL2RenderingContext' || !!(gl as any).HALF_FLOAT

  let halfFloat: any = null
  let supportLinearFiltering = false
  let halfFloatTexType: number
  let formatRGBA: any, formatRG: any, formatR: any

  if (isWebGL2) {
    const gl2 = gl as WebGL2RenderingContext
    if (!gl2.getExtension('EXT_color_buffer_float')) return null
    supportLinearFiltering = !!gl2.getExtension('OES_texture_float_linear')
    halfFloatTexType = gl2.HALF_FLOAT
    formatRGBA = { internalFormat: gl2.RGBA16F, format: gl2.RGBA }
    formatRG = { internalFormat: gl2.RG16F, format: gl2.RG }
    formatR = { internalFormat: gl2.R16F, format: gl2.RED }
  } else {
    halfFloat = gl.getExtension('OES_texture_half_float')
    supportLinearFiltering = !!gl.getExtension('OES_texture_half_float_linear')
    halfFloatTexType = halfFloat?.HALF_FLOAT_OES
    formatRGBA = { internalFormat: gl.RGBA, format: gl.RGBA }
    formatRG = { internalFormat: gl.RGBA, format: gl.RGBA }
    formatR = { internalFormat: gl.RGBA, format: gl.RGBA }
  }

  if (!isWebGL2 && halfFloatTexType === undefined) return null

  const shaders = new Set<WebGLShader>()
  const programs = new Set<WebGLProgram>()
  const buffers = new Set<WebGLBuffer>()
  const textures = new Set<WebGLTexture>()
  const framebuffers = new Set<WebGLFramebuffer>()
  gl.clearColor(0, 0, 0, 1)

  function getResolution(resolution: number) {
    let aspectRatio = (gl as any).drawingBufferWidth / (gl as any).drawingBufferHeight
    if (aspectRatio < 1) aspectRatio = 1.0 / aspectRatio
    const min = Math.round(resolution)
    const max = Math.round(resolution * aspectRatio)
    return (gl as any).drawingBufferWidth > (gl as any).drawingBufferHeight
      ? { width: max, height: min }
      : { width: min, height: max }
  }

  function compileShader(type: number, source: string, keywords?: string[]) {
    source = keywords ? keywords.map(k => `#define ${k}\n`).join('') + source : source
    const shader = gl.createShader(type)!
    shaders.add(shader)
    gl.shaderSource(shader, source)
    gl.compileShader(shader)
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw gl.getShaderInfoLog(shader)
    return shader
  }

  function createProgram(vs: WebGLShader, fs: WebGLShader) {
    const program = gl.createProgram()!
    programs.add(program)
    gl.attachShader(program, vs)
    gl.attachShader(program, fs)
    gl.linkProgram(program)
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw gl.getProgramInfoLog(program)
    return program
  }

  function getUniforms(program: WebGLProgram) {
    const uniforms: Record<string, WebGLUniformLocation | null> = {}
    const count = gl.getProgramParameter(program, gl.ACTIVE_UNIFORMS)
    for (let i = 0; i < count; i++) {
      const name = gl.getActiveUniform(program, i)!.name
      uniforms[name] = gl.getUniformLocation(program, name)
    }
    return uniforms
  }

  const baseVertexShader = compileShader(gl.VERTEX_SHADER, `
    precision highp float;
    attribute vec2 aPosition;
    varying vec2 vUv;
    varying vec2 vL;
    varying vec2 vR;
    varying vec2 vT;
    varying vec2 vB;
    uniform vec2 texelSize;
    void main () {
      vUv = aPosition * 0.5 + 0.5;
      vL = vUv - vec2(texelSize.x, 0.0);
      vR = vUv + vec2(texelSize.x, 0.0);
      vT = vUv + vec2(0.0, texelSize.y);
      vB = vUv - vec2(0.0, texelSize.y);
      gl_Position = vec4(aPosition, 0.0, 1.0);
    }
  `)

  const displayShaderSource = `
    precision highp float;
    precision highp sampler2D;
    varying vec2 vUv;
    varying vec2 vL;
    varying vec2 vR;
    varying vec2 vT;
    varying vec2 vB;
    uniform sampler2D uTexture;
    void main () {
      vec3 c = texture2D(uTexture, vUv).rgb;
      #ifdef SHADING
        vec3 lc = texture2D(uTexture, vL).rgb;
        vec3 rc = texture2D(uTexture, vR).rgb;
        vec3 tc = texture2D(uTexture, vT).rgb;
        vec3 bc = texture2D(uTexture, vB).rgb;
        float dx = length(rc) - length(lc);
        float dy = length(tc) - length(bc);
        vec3 n = normalize(vec3(dx, dy, length(texelSize)));
        vec3 l = vec3(0.0, 0.0, 1.0);
        float diffuse = clamp(dot(n, l) + 0.7, 0.7, 1.0);
        c *= diffuse;
      #endif
      float a = max(c.r, max(c.g, c.b));
      gl_FragColor = vec4(c, a);
    }
  `

  const splatShader = compileShader(gl.FRAGMENT_SHADER, `
    precision highp float;
    precision highp sampler2D;
    varying vec2 vUv;
    uniform sampler2D uTarget;
    uniform float aspectRatio;
    uniform vec3 color;
    uniform vec2 point;
    uniform float radius;
    void main () {
      vec2 p = vUv - point.xy;
      p.x *= aspectRatio;
      vec3 splat = exp(-dot(p, p) / radius) * color;
      vec3 base = texture2D(uTarget, vUv).xyz;
      gl_FragColor = vec4(base + splat, 1.0);
    }
  `)

  const advectionShader = compileShader(gl.FRAGMENT_SHADER, `
    precision highp float;
    precision highp sampler2D;
    varying vec2 vUv;
    uniform sampler2D uVelocity;
    uniform sampler2D uSource;
    uniform vec2 texelSize;
    uniform vec2 dyeTexelSize;
    uniform float dt;
    uniform float dissipation;
    void main () {
      vec2 coord = vUv - dt * texture2D(uVelocity, vUv).xy * texelSize;
      vec4 result = texture2D(uSource, coord);
      float decay = 1.0 + dissipation * dt;
      gl_FragColor = result / decay;
    }
  `, supportLinearFiltering ? null : ['MANUAL_FILTERING'])

  const divergenceShader = compileShader(gl.FRAGMENT_SHADER, `
    precision mediump float;
    precision mediump sampler2D;
    varying highp vec2 vUv;
    varying highp vec2 vL;
    varying highp vec2 vR;
    varying highp vec2 vT;
    varying highp vec2 vB;
    uniform sampler2D uVelocity;
    void main () {
      float L = texture2D(uVelocity, vL).x;
      float R = texture2D(uVelocity, vR).x;
      float T = texture2D(uVelocity, vT).y;
      float B = texture2D(uVelocity, vB).y;
      vec2 C = texture2D(uVelocity, vUv).xy;
      if (vL.x < 0.0) { L = -C.x; }
      if (vR.x > 1.0) { R = -C.x; }
      if (vT.y > 1.0) { T = -C.y; }
      if (vB.y < 0.0) { B = -C.y; }
      float div = 0.5 * (R - L + T - B);
      gl_FragColor = vec4(div, 0.0, 0.0, 1.0);
    }
  `)

  const curlShader = compileShader(gl.FRAGMENT_SHADER, `
    precision mediump float;
    precision mediump sampler2D;
    varying highp vec2 vUv;
    varying highp vec2 vL;
    varying highp vec2 vR;
    varying highp vec2 vT;
    varying highp vec2 vB;
    uniform sampler2D uVelocity;
    void main () {
      float L = texture2D(uVelocity, vL).y;
      float R = texture2D(uVelocity, vR).y;
      float T = texture2D(uVelocity, vT).x;
      float B = texture2D(uVelocity, vB).x;
      float vorticity = R - L - T + B;
      gl_FragColor = vec4(0.5 * vorticity, 0.0, 0.0, 1.0);
    }
  `)

  const vorticityShader = compileShader(gl.FRAGMENT_SHADER, `
    precision highp float;
    precision highp sampler2D;
    varying vec2 vUv;
    varying vec2 vL;
    varying vec2 vR;
    varying vec2 vT;
    varying vec2 vB;
    uniform sampler2D uVelocity;
    uniform sampler2D uCurl;
    uniform float curl;
    uniform float dt;
    void main () {
      float L = texture2D(uCurl, vL).x;
      float R = texture2D(uCurl, vR).x;
      float T = texture2D(uCurl, vT).x;
      float B = texture2D(uCurl, vB).x;
      float C = texture2D(uCurl, vUv).x;
      vec2 force = 0.5 * vec2(abs(T) - abs(B), abs(R) - abs(L));
      force /= length(force) + 0.0001;
      force *= curl * C;
      force.y *= -1.0;
      vec2 vel = texture2D(uVelocity, vUv).xy;
      gl_FragColor = vec4(vel + force * dt, 0.0, 1.0);
    }
  `)

  const pressureShader = compileShader(gl.FRAGMENT_SHADER, `
    precision mediump float;
    precision mediump sampler2D;
    varying highp vec2 vUv;
    varying highp vec2 vL;
    varying highp vec2 vR;
    varying highp vec2 vT;
    varying highp vec2 vB;
    uniform sampler2D uPressure;
    uniform sampler2D uDivergence;
    void main () {
      float L = texture2D(uPressure, vL).x;
      float R = texture2D(uPressure, vR).x;
      float T = texture2D(uPressure, vT).x;
      float B = texture2D(uPressure, vB).x;
      float divergence = texture2D(uDivergence, vUv).x;
      float pressure = (L + R + B + T - divergence) * 0.25;
      gl_FragColor = vec4(pressure, 0.0, 0.0, 1.0);
    }
  `)

  const gradientSubtractShader = compileShader(gl.FRAGMENT_SHADER, `
    precision mediump float;
    precision mediump sampler2D;
    varying highp vec2 vUv;
    varying highp vec2 vL;
    varying highp vec2 vR;
    varying highp vec2 vT;
    varying highp vec2 vB;
    uniform sampler2D uPressure;
    uniform sampler2D uVelocity;
    void main () {
      float L = texture2D(uPressure, vL).x;
      float R = texture2D(uPressure, vR).x;
      float T = texture2D(uPressure, vT).x;
      float B = texture2D(uPressure, vB).x;
      vec2 velocity = texture2D(uVelocity, vUv).xy;
      velocity.xy -= vec2(R - L, T - B);
      gl_FragColor = vec4(velocity, 0.0, 1.0);
    }
  `)

  const clearShader = compileShader(gl.FRAGMENT_SHADER, `
    precision mediump float;
    precision mediump sampler2D;
    varying highp vec2 vUv;
    uniform sampler2D uTexture;
    uniform float value;
    void main () {
      gl_FragColor = value * texture2D(uTexture, vUv);
    }
  `)

  const copyShader = compileShader(gl.FRAGMENT_SHADER, `
    precision mediump float;
    precision mediump sampler2D;
    varying highp vec2 vUv;
    uniform sampler2D uTexture;
    void main () {
      gl_FragColor = texture2D(uTexture, vUv);
    }
  `)

  const blurVertexShader = compileShader(gl.VERTEX_SHADER, `
    precision highp float;
    attribute vec2 aPosition;
    varying vec2 vUv;
    varying vec2 vL;
    varying vec2 vR;
    uniform vec2 texelSize;
    void main () {
      vUv = aPosition * 0.5 + 0.5;
      float offset = 1.33333333;
      vL = vUv - texelSize * offset;
      vR = vUv + texelSize * offset;
      gl_Position = vec4(aPosition, 0.0, 1.0);
    }
  `)

  const blurShader = compileShader(gl.FRAGMENT_SHADER, `
    precision mediump float;
    precision mediump sampler2D;
    varying vec2 vUv;
    varying vec2 vL;
    varying vec2 vR;
    uniform sampler2D uTexture;
    void main () {
      vec4 sum = texture2D(uTexture, vUv) * 0.29411764;
      sum += texture2D(uTexture, vL) * 0.35294117;
      sum += texture2D(uTexture, vR) * 0.35294117;
      gl_FragColor = sum;
    }
  `)

  // @ts-ignore
  const glAny = gl as any

  const blit = (() => {
    const buf = gl.createBuffer()!
    buffers.add(buf)
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, -1, 1, 1, 1, 1, -1]), gl.STATIC_DRAW)
    const idxBuf = gl.createBuffer()!
    buffers.add(idxBuf)
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, idxBuf)
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array([0, 1, 2, 0, 2, 3]), gl.STATIC_DRAW)
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0)
    gl.enableVertexAttribArray(0)
    return (dest: WebGLFramebuffer | null) => {
      gl.bindFramebuffer(gl.FRAMEBUFFER, dest)
      gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0)
    }
  })()

  class Program {
    uniforms: Record<string, WebGLUniformLocation | null>
    program: WebGLProgram
    constructor(vs: WebGLShader, fs: WebGLShader) {
      this.program = createProgram(vs, fs)
      this.uniforms = getUniforms(this.program)
    }
    bind() { gl.useProgram(this.program) }
  }

  function createFBO(w: number, h: number, intFmt: number, fmt: number, type: number, filter: number) {
    gl.activeTexture(gl.TEXTURE0)
    const tex = gl.createTexture()!
    textures.add(tex)
    gl.bindTexture(gl.TEXTURE_2D, tex)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
    gl.texImage2D(gl.TEXTURE_2D, 0, intFmt, w, h, 0, fmt, type, null)
    const fbo = gl.createFramebuffer()!
    framebuffers.add(fbo)
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo)
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0)
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error('Float framebuffer unavailable')
    gl.viewport(0, 0, w, h)
    gl.clear(gl.COLOR_BUFFER_BIT)
    const tx = 1.0 / w, ty = 1.0 / h
    return {
      texture: tex, fbo, width: w, height: h, texelSizeX: tx, texelSizeY: ty,
      attach(id: number) { gl.activeTexture(gl.TEXTURE0 + id); gl.bindTexture(gl.TEXTURE_2D, tex); return id }
    }
  }

  function createDoubleFBO(w: number, h: number, intFmt: number, fmt: number, type: number, filter: number) {
    let fbo1 = createFBO(w, h, intFmt, fmt, type, filter)
    let fbo2 = createFBO(w, h, intFmt, fmt, type, filter)
    return {
      width: w, height: h, texelSizeX: fbo1.texelSizeX, texelSizeY: fbo1.texelSizeY,
      get read() { return fbo1 }, set read(v) { fbo1 = v },
      get write() { return fbo2 }, set write(v) { fbo2 = v },
      swap() { const t = fbo1; fbo1 = fbo2; fbo2 = t }
    }
  }

  const blurProgram = new Program(blurVertexShader, blurShader)
  const copyProgram = new Program(baseVertexShader, copyShader)
  const clearProgram = new Program(baseVertexShader, clearShader)
  const splatProgram = new Program(baseVertexShader, splatShader)
  const advectionProgram = new Program(baseVertexShader, advectionShader)
  const divergenceProgram = new Program(baseVertexShader, divergenceShader)
  const curlProgram = new Program(baseVertexShader, curlShader)
  const vorticityProgram = new Program(baseVertexShader, vorticityShader)
  const pressureProgram = new Program(baseVertexShader, pressureShader)
  const gradientSubtractProgram = new Program(baseVertexShader, gradientSubtractShader)

  let dye: ReturnType<typeof createDoubleFBO>
  let velocity: ReturnType<typeof createDoubleFBO>
  let divergenceFBO: ReturnType<typeof createFBO>
  let curlFBO: ReturnType<typeof createFBO>
  let pressure: ReturnType<typeof createDoubleFBO>

  const filter = supportLinearFiltering ? glAny?.LINEAR || gl.LINEAR : gl.NEAREST

  function disposeFramebuffers() {
    textures.forEach(texture => gl.deleteTexture(texture))
    framebuffers.forEach(framebuffer => gl.deleteFramebuffer(framebuffer))
    textures.clear()
    framebuffers.clear()
  }

  function initFramebuffers() {
    disposeFramebuffers()
    const simRes = getResolution(config.SIM_RESOLUTION)
    const dyeRes = getResolution(config.DYE_RESOLUTION)
    dye = createDoubleFBO(dyeRes.width, dyeRes.height, formatRGBA.internalFormat, formatRGBA.format, halfFloatTexType, filter)
    velocity = createDoubleFBO(simRes.width, simRes.height, formatRG.internalFormat, formatRG.format, halfFloatTexType, filter)
    divergenceFBO = createFBO(simRes.width, simRes.height, formatR.internalFormat, formatR.format, halfFloatTexType, gl.NEAREST)
    curlFBO = createFBO(simRes.width, simRes.height, formatR.internalFormat, formatR.format, halfFloatTexType, gl.NEAREST)
    pressure = createDoubleFBO(simRes.width, simRes.height, formatR.internalFormat, formatR.format, halfFloatTexType, gl.NEAREST)
  }

  function generateColor() {
    const c = HSVtoRGB(Math.random(), 1.0, 1.0)
    return { r: c.r * 0.25, g: c.g * 0.25, b: c.b * 0.25 }
  }

  function HSVtoRGB(h: number, s: number, v: number) {
    let r = 0, g = 0, b = 0
    const i = Math.floor(h * 6)
    const f = h * 6 - i
    const p = v * (1 - s)
    const q = v * (1 - f * s)
    const t = v * (1 - (1 - f) * s)
    switch (i % 6) {
      case 0: r = v; g = t; b = p; break
      case 1: r = q; g = v; b = p; break
      case 2: r = p; g = v; b = t; break
      case 3: r = p; g = q; b = v; break
      case 4: r = t; g = p; b = v; break
      case 5: r = v; g = p; b = q; break
    }
    return { r, g, b }
  }

  function splat(x: number, y: number, dx: number, dy: number, color: { r: number; g: number; b: number }) {
    gl.viewport(0, 0, velocity.width, velocity.height)
    splatProgram.bind()
    gl.uniform1i(splatProgram.uniforms.uTarget, velocity.read.attach(0))
    gl.uniform1f(splatProgram.uniforms.aspectRatio, canvas.width / canvas.height)
    gl.uniform2f(splatProgram.uniforms.point, x, y)
    gl.uniform3f(splatProgram.uniforms.color, dx, dy, 0.0)
    gl.uniform1f(splatProgram.uniforms.radius, correctRadius(config.SPLAT_RADIUS / 100.0))
    blit(velocity.write.fbo)
    velocity.swap()

    gl.viewport(0, 0, dye.width, dye.height)
    gl.uniform1i(splatProgram.uniforms.uTarget, dye.read.attach(0))
    gl.uniform3f(splatProgram.uniforms.color, color.r, color.g, color.b)
    blit(dye.write.fbo)
    dye.swap()
  }

  function multipleSplats(amount: number) {
    for (let i = 0; i < amount; i++) {
      const c = generateColor()
      c.r *= 10; c.g *= 10; c.b *= 10
      splat(Math.random(), Math.random(), 1000 * (Math.random() - 0.5), 1000 * (Math.random() - 0.5), c)
    }
  }

  function correctRadius(r: number) {
    const ar = canvas.width / canvas.height
    if (ar > 1) r *= ar
    return r
  }

  function step(dt: number) {
    gl.disable(gl.BLEND)
    gl.viewport(0, 0, velocity.width, velocity.height)
    curlProgram.bind()
    gl.uniform2f(curlProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY)
    gl.uniform1i(curlProgram.uniforms.uVelocity, velocity.read.attach(0))
    blit(curlFBO.fbo)

    vorticityProgram.bind()
    gl.uniform2f(vorticityProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY)
    gl.uniform1i(vorticityProgram.uniforms.uVelocity, velocity.read.attach(0))
    gl.uniform1i(vorticityProgram.uniforms.uCurl, curlFBO.attach(1))
    gl.uniform1f(vorticityProgram.uniforms.curl, config.CURL)
    gl.uniform1f(vorticityProgram.uniforms.dt, dt)
    blit(velocity.write.fbo)
    velocity.swap()

    divergenceProgram.bind()
    gl.uniform2f(divergenceProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY)
    gl.uniform1i(divergenceProgram.uniforms.uVelocity, velocity.read.attach(0))
    blit(divergenceFBO.fbo)

    clearProgram.bind()
    gl.uniform1i(clearProgram.uniforms.uTexture, pressure.read.attach(0))
    gl.uniform1f(clearProgram.uniforms.value, config.PRESSURE)
    blit(pressure.write.fbo)
    pressure.swap()

    pressureProgram.bind()
    gl.uniform2f(pressureProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY)
    gl.uniform1i(pressureProgram.uniforms.uDivergence, divergenceFBO.attach(0))
    for (let i = 0; i < config.PRESSURE_ITERATIONS; i++) {
      gl.uniform1i(pressureProgram.uniforms.uPressure, pressure.read.attach(1))
      blit(pressure.write.fbo)
      pressure.swap()
    }

    gradientSubtractProgram.bind()
    gl.uniform2f(gradientSubtractProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY)
    gl.uniform1i(gradientSubtractProgram.uniforms.uPressure, pressure.read.attach(0))
    gl.uniform1i(gradientSubtractProgram.uniforms.uVelocity, velocity.read.attach(1))
    blit(velocity.write.fbo)
    velocity.swap()

    advectionProgram.bind()
    gl.uniform2f(advectionProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY)
    if (!supportLinearFiltering) gl.uniform2f(advectionProgram.uniforms.dyeTexelSize, velocity.texelSizeX, velocity.texelSizeY)
    gl.uniform1i(advectionProgram.uniforms.uVelocity, velocity.read.attach(0))
    gl.uniform1i(advectionProgram.uniforms.uSource, velocity.read.attach(0))
    gl.uniform1f(advectionProgram.uniforms.dt, dt)
    gl.uniform1f(advectionProgram.uniforms.dissipation, config.VELOCITY_DISSIPATION)
    blit(velocity.write.fbo)
    velocity.swap()

    gl.viewport(0, 0, dye.width, dye.height)
    if (!supportLinearFiltering) gl.uniform2f(advectionProgram.uniforms.dyeTexelSize, dye.texelSizeX, dye.texelSizeY)
    gl.uniform1i(advectionProgram.uniforms.uVelocity, velocity.read.attach(0))
    gl.uniform1i(advectionProgram.uniforms.uSource, dye.read.attach(1))
    gl.uniform1f(advectionProgram.uniforms.dissipation, config.DENSITY_DISSIPATION)
    blit(dye.write.fbo)
    dye.swap()
  }

  const displayProgram = new Program(baseVertexShader, compileShader(gl.FRAGMENT_SHADER, `
      precision highp float;
      precision highp sampler2D;
      varying vec2 vUv;
      uniform sampler2D uTexture;
      void main () {
        vec3 c = texture2D(uTexture, vUv).rgb;
        float a = max(c.r, max(c.g, c.b));
        gl_FragColor = vec4(c, a);
      }
    `))

  function render() {
    gl.viewport(0, 0, glAny.drawingBufferWidth, glAny.drawingBufferHeight)
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA)
    gl.enable(gl.BLEND)

    displayProgram.bind()
    gl.uniform1i(displayProgram.uniforms.uTexture, dye.read.attach(0))
    blit(null)
  }

  let animRunning = true
  let nextSplash = Date.now() + 3000
  function update() {
    if (!animRunning) return
    const now = Date.now()
    if (now >= nextSplash) {
      splatStack.push(2)
      nextSplash = now + 3000
    }
    let dt = (now - lastUpdateTime) / 1000
    dt = Math.min(dt, 0.016666)
    lastUpdateTime = now

    if (config.COLORFUL) {
      colorUpdateTimer += dt * config.COLOR_UPDATE_SPEED
      if (colorUpdateTimer >= 1) {
        colorUpdateTimer = colorUpdateTimer % 1
        pointers.forEach(p => { p.color = generateColor() })
      }
    }

    if (splatStack.length > 0) multipleSplats(splatStack.pop()!)
    pointers.forEach(p => {
      if (p.moved) { p.moved = false; splatPointer(p) }
    })

    if (!config.PAUSED) step(dt)
    render()
    animationId = requestAnimationFrame(update)
  }

  function splatPointer(p: ReturnType<typeof pointerPrototype>) {
    const dx = p.deltaX * config.SPLAT_FORCE
    const dy = p.deltaY * config.SPLAT_FORCE
    splat(p.texcoordX, p.texcoordY, dx, dy, p.color)
  }

  function scaleByPixelRatio(input: number) {
    return Math.floor(input * pixelRatio)
  }

  function updatePointerDownData(p: ReturnType<typeof pointerPrototype>, id: number, posX: number, posY: number) {
    p.id = id; p.down = true; p.moved = false
    p.texcoordX = posX / canvas.width; p.texcoordY = 1.0 - posY / canvas.height
    p.prevTexcoordX = p.texcoordX; p.prevTexcoordY = p.texcoordY
    p.deltaX = 0; p.deltaY = 0; p.color = generateColor()
  }

  function updatePointerMoveData(p: ReturnType<typeof pointerPrototype>, posX: number, posY: number) {
    p.prevTexcoordX = p.texcoordX; p.prevTexcoordY = p.texcoordY
    p.texcoordX = posX / canvas.width; p.texcoordY = 1.0 - posY / canvas.height
    p.deltaX = correctDeltaX(p.texcoordX - p.prevTexcoordX)
    p.deltaY = correctDeltaY(p.texcoordY - p.prevTexcoordY)
    p.moved = Math.abs(p.deltaX) > 0 || Math.abs(p.deltaY) > 0
  }

  function correctDeltaX(d: number) {
    const ar = canvas.width / canvas.height
    if (ar < 1) d *= ar
    return d
  }
  function correctDeltaY(d: number) {
    const ar = canvas.width / canvas.height
    if (ar > 1) d /= ar
    return d
  }

  function resizeCanvas() {
    const w = scaleByPixelRatio(canvas.clientWidth)
    const h = scaleByPixelRatio(canvas.clientHeight)
    if (!dye || canvas.width !== w || canvas.height !== h) {
      canvas.width = w
      canvas.height = h
      initFramebuffers()
      if (!animRunning) { multipleSplats(3); render() }
    }
  }

  resizeCanvas()
  multipleSplats(Math.floor(Math.random() * 8) + 3)
  update()

  const controller = new AbortController()
  const pointer = pointers[0]!
  const coordinates = (event: PointerEvent) => {
    const bounds = canvas.getBoundingClientRect()
    return [scaleByPixelRatio(event.clientX - bounds.left), scaleByPixelRatio(event.clientY - bounds.top)]
  }
  const onDown = (event: PointerEvent) => {
    if (!event.isPrimary || event.button !== 0) return
    canvas.setPointerCapture(event.pointerId)
    const [x, y] = coordinates(event)
    updatePointerDownData(pointer, event.pointerId, x, y)
    const color = generateColor()
    splat(pointer.texcoordX, pointer.texcoordY, 30, 30, { r: color.r * 8, g: color.g * 8, b: color.b * 8 })
    if (!animRunning) render()
  }
  const onMove = (event: PointerEvent) => {
    if (!pointer.down || event.pointerId !== pointer.id) return
    const [x, y] = coordinates(event)
    updatePointerMoveData(pointer, x, y)
    if (!animRunning) { splatPointer(pointer); pointer.moved = false; render() }
  }
  const onUp = (event: PointerEvent) => {
    if (event.pointerId === pointer.id) pointer.down = false
  }
  const options = { signal: controller.signal }
  canvas.addEventListener('pointerdown', onDown, options)
  canvas.addEventListener('pointermove', onMove, options)
  canvas.addEventListener('pointerup', onUp, options)
  canvas.addEventListener('pointercancel', onUp, options)
  canvas.addEventListener('lostpointercapture', onUp, options)
  window.addEventListener('resize', resizeCanvas, options)

  return {
    cleanup: () => {
      animRunning = false
      if (animationId) cancelAnimationFrame(animationId)
      animationId = null
      controller.abort()
      disposeFramebuffers()
      buffers.forEach(buffer => gl.deleteBuffer(buffer))
      programs.forEach(program => gl.deleteProgram(program))
      shaders.forEach(shader => gl.deleteShader(shader))
      if (!gl.isContextLost()) gl.getExtension('WEBGL_lose_context')?.loseContext()
    },
    pause: () => {
      animRunning = false
      if (animationId) cancelAnimationFrame(animationId)
      animationId = null
    },
    resume: () => {
      if (!animRunning) {
        animRunning = true
        lastUpdateTime = Date.now()
        nextSplash = lastUpdateTime + 3000
        update()
      }
    },
  }
}
</script>

<template>
  <div class="fluid-surface" @pointerdown="touchGlow" @pointermove="touchGlow"
    :style="{ '--glow-x': glow.x + '%', '--glow-y': glow.y + '%' }">
    <div class="soft-light" aria-hidden="true" />
    <canvas ref="canvasRef" class="fluid-canvas" :class="{ unavailable: failed }"
      aria-label="按住并拖动，绘制生日光影" @webglcontextlost.prevent="contextLost" />
  </div>
</template>

<style scoped>
.fluid-surface, .soft-light { position: absolute; inset: 0; }
.fluid-surface { touch-action: none; }
.soft-light { background: radial-gradient(ellipse at var(--glow-x, 50%) var(--glow-y, 50%), #5d296b88, transparent 58%), radial-gradient(ellipse at 85% 72%, #245e8080, transparent 55%), #080912; }
.unavailable { opacity: 0; }
.fluid-canvas {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  z-index: 0;
  display: block;
  touch-action: none;
}
</style>
