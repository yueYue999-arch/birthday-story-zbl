<script setup lang="ts">
import { onUnmounted, ref } from 'vue'
import type { GiftContent } from '../content'
const props = defineProps<{ gift: GiftContent }>()
const emit = defineEmits<{ login: [] }>()
const name = ref('')
const error = ref('')
const counting = ref(false)
const remaining = ref(14)
let timer: ReturnType<typeof setInterval> | undefined
let finished = false
const logs = props.gift.id === 'zbl'
  ? ['正在验证身份…', '检测到「龙傲天」血脉…', '主角光环注入中…', '人生剧本准备就绪']
  : ['正在打开你的礼物…', '把回忆慢慢铺开…', '收集每一句祝福…', '你的故事准备就绪']

function finish() {
  if (finished) return
  finished = true
  clearInterval(timer)
  emit('login')
}
function start() {
  if (counting.value) return
  if (name.value.trim() !== props.gift.recipient) {
    error.value = `这份礼物写给${props.gift.recipient}，请输入这个名字。`
    return
  }
  error.value = ''
  ;(document.activeElement as HTMLElement | null)?.blur()
  counting.value = true
  const end = Date.now() + 14000
  timer = setInterval(() => {
    remaining.value = Math.max(0, Math.ceil((end - Date.now()) / 1000))
    if (remaining.value === 0) finish()
  }, 200)
}
onUnmounted(() => clearInterval(timer))
</script>

<template>
  <section class="login-page">
    <form v-if="!counting" @submit.prevent="start">
      <p class="invitation">{{ gift.invitation }}</p>
      <h1>你是谁？</h1>
      <label for="recipient-name">收礼人的名字</label>
      <input id="recipient-name" v-model="name" type="text" placeholder="输入你的名字" autocomplete="off"
        enterkeyhint="go" maxlength="30" :aria-invalid="!!error" :aria-describedby="error ? 'name-error' : undefined" @input="error = ''" />
      <p v-if="error" id="name-error" class="form-error" role="alert">{{ error }}</p>
      <button class="enter-button" type="submit">进入</button>
    </form>
    <div v-else class="countdown" aria-label="生日开场">
      <div class="terminal-grid" aria-hidden="true" />
      <p class="countdown-label">你的故事，即将开始</p>
      <p class="countdown-number" aria-live="off">{{ remaining }}</p>
      <div class="boot-log" aria-hidden="true">
        <p v-for="(log, index) in logs.slice(0, Math.min(4, 1 + Math.floor((14 - remaining) / 4)))" :key="index">&gt; {{ log }}</p>
      </div>
      <button class="skip-button" type="button" @click="finish">跳过开场</button>
    </div>
  </section>
</template>

<style scoped>
.login-page { width: 100%; height: 100%; background: #fafaf9; color: #242424; font-family: 'Songti SC', SimSun, serif; overflow-y: auto; display: grid; align-items: center; padding: max(88px, calc(env(safe-area-inset-top) + 72px)) max(24px, env(safe-area-inset-right)) max(32px, env(safe-area-inset-bottom)); }
form { width: min(880px, 100%); margin: auto; display: flex; flex-direction: column; gap: 16px; }
.invitation { color: #666; font-size: 14px; }
h1 { font-size: clamp(36px, 6vw, 64px); font-weight: 400; margin-bottom: 16px; }
label { font-size: 16px; color: #555; }
input { width: 100%; min-width: 0; padding: clamp(16px, 3vw, 32px); font-family: inherit; font-size: clamp(24px, 5vw, 52px); background: #fff; border: 2px solid #777; border-radius: 0; color: #242424; }
input:focus { outline: 3px solid #535b70; outline-offset: 4px; }
.enter-button { align-self: flex-start; min-height: 48px; min-width: 128px; margin-top: 8px; border: 1px solid #555; background: #282828; color: #fff; font-size: 18px; }
.form-error { color: #a42620; line-height: 1.6; font-family: system-ui, sans-serif; }
.countdown { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 16px; color: #66ff97; background: #020b06; overflow: hidden; font-family: Consolas, monospace; }
.terminal-grid { position: absolute; inset: 0; opacity: .3; pointer-events: none; background-image: linear-gradient(#36c77016 1px, transparent 1px), linear-gradient(90deg, #36c77016 1px, transparent 1px); background-size: 32px 32px; }
.countdown-label { font-size: 16px; }
.countdown-number { font-size: clamp(96px, 26vmin, 208px); line-height: 1; font-weight: 700; text-shadow: 0 0 28px #3aea7833; }
.boot-log { min-height: 112px; width: min(440px, calc(100% - 48px)); padding: 12px; border-left: 2px solid #42bf66; font-size: clamp(12px, 3vw, 15px); line-height: 1.9; }
.skip-button { position: absolute; right: 24px; bottom: max(24px, env(safe-area-inset-bottom)); min-height: 44px; padding: 0 16px; border: 1px solid #65bc83; border-radius: 6px; background: #05190c; color: #bfffd2; }
@media (max-height: 460px) { .countdown { gap: 8px; }.countdown-number { font-size: 80px; }.boot-log { min-height: 90px; } }
</style>

