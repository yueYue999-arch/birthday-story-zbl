<script setup lang="ts">
import { computed, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import { draftKey, encodeGift, maxContentBytes, shareBase, validateGift, type GiftContent } from '../content'

const props = defineProps<{ gift: GiftContent }>()
const cloneCurrent = (): GiftContent => JSON.parse(JSON.stringify(props.gift))
const emit = defineEmits<{ close: []; preview: [gift: GiftContent] }>()
const dialog = ref<HTMLDialogElement | null>(null)
const form = ref<HTMLFormElement | null>(null)
const draft = ref<GiftContent>(cloneCurrent())
const error = ref('')
const note = ref('')
const link = ref('')
const busy = ref(false)
const fileInput = ref<HTMLInputElement | null>(null)
const returnFocus = document.activeElement as HTMLElement | null
const fields = [
  { key: 'recipient', label: '收礼人的名字', max: 30, required: true },
  { key: 'greeting', label: '首页祝福', max: 30, required: true },
  { key: 'date', label: '展示日期', max: 40, required: false },
  { key: 'invitation', label: '入口邀请语', max: 100, required: true },
  { key: 'subtitle', label: '首页副标题', max: 120, required: false },
  { key: 'english', label: '英文祝福（可留空）', max: 80, required: false },
] as const
const chapterCount = computed(() => draft.value.chapters.length)
let saveTimer: ReturnType<typeof setTimeout>

function saveDraft() {
  try { localStorage.setItem(draftKey, JSON.stringify(draft.value)); note.value = '草稿已保存在这台设备' }
  catch { note.value = '此浏览器无法保存草稿，请导出内容文件备份' }
}
watch(draft, () => {
  link.value = ''
  error.value = ''
  clearTimeout(saveTimer)
  saveTimer = setTimeout(saveDraft, 400)
}, { deep: true })

function checked(): GiftContent | null {
  if (!form.value?.reportValidity()) return null
  try {
    const gift = validateGift(draft.value)
    // The original public case always keeps its own progress and content.
    if (gift.id === 'zbl') gift.id = crypto.randomUUID()
    return gift
  } catch (cause) { error.value = (cause as Error).message; return null }
}
function preview() {
  const gift = checked()
  if (gift) { saveDraft(); emit('preview', gift) }
}
async function makeLink() {
  const gift = checked()
  if (!gift || busy.value) return
  busy.value = true
  error.value = ''
  try {
    const hash = await encodeGift(gift)
    link.value = shareBase(window.location.href) + hash
    note.value = '专属链接已生成，可复制发送给朋友'
    await nextTick()
    dialog.value?.querySelector<HTMLElement>('.share-result')?.scrollIntoView({ block: 'nearest' })
  } catch (cause) { error.value = (cause as Error).message }
  finally { busy.value = false }
}
async function copyLink() {
  try { await navigator.clipboard.writeText(link.value); note.value = '完整链接已复制' }
  catch { note.value = '请长按下方链接，选择全选并复制' }
}
function exportFile() {
  const gift = checked()
  if (!gift) return
  const url = URL.createObjectURL(new Blob([JSON.stringify(gift, null, 2)], { type: 'application/json' }))
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = `祝福内容-${gift.recipient.replace(/[\\/:*?"<>|]/g, '_')}.json`
  anchor.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
  note.value = '内容文件已导出，可在编辑页重新导入'
}
async function importFile(event: Event) {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  try {
    if (file.size > maxContentBytes) throw new Error('文件太大，请导入小于 100 KB 的内容 JSON。')
    draft.value = validateGift(JSON.parse(await file.text()))
    await nextTick()
    saveDraft()
  } catch (cause) { error.value = cause instanceof SyntaxError ? '文件不是有效的 JSON，请使用导出的内容文件。' : (cause as Error).message }
  input.value = ''
}
function blankGift() {
  draft.value = {
    version: 1, id: crypto.randomUUID(), recipient: '朋友', invitation: '一份只为你准备的祝福',
    greeting: '生日快乐', date: '', subtitle: '把想说的话，写进这份礼物', english: 'Best wishes',
    storyTitle: '我们的故事', epigraph: '',
    chapters: [{ title: '相遇的那一天', body: '在这里写下属于你们的故事。', quote: '', closing: '' }],
    wishesTitle: '送给你的话', wishes: ['愿你走向更广阔的天地，保持热爱，也享受当下。'],
    blessing: '愿每一天都有新的惊喜。', signature: '',
  }
  dialog.value?.querySelector<HTMLInputElement>('#edit-recipient')?.focus()
}
onMounted(() => {
  try {
    const saved = localStorage.getItem(draftKey)
    if (saved) { draft.value = validateGift(JSON.parse(saved)); note.value = '已恢复这台设备的草稿' }
  } catch { note.value = '旧草稿无法读取，已载入当前页面内容' }
  dialog.value?.showModal()
})
onUnmounted(() => {
  clearTimeout(saveTimer)
  saveDraft()
  returnFocus?.focus({ preventScroll: true })
})
</script>

<template>
  <dialog ref="dialog" class="gift-editor" aria-labelledby="editor-title" @cancel.prevent="emit('close')">
    <header class="editor-heading">
      <div><h1 id="editor-title">写一份专属祝福</h1><p>生日、告别、入职、欢迎，都可以从这里开始。</p></div>
      <button type="button" class="close-editor" @click="emit('close')">关闭编辑</button>
    </header>
    <form ref="form" class="editor-form" @submit.prevent="preview">
      <aside class="editor-guide">
        <p>名字、故事、寄语，都由你来写。</p>
        <p>预览满意后生成专属链接。编辑不会覆盖原来的朱博乐页面。</p>
        <div class="file-tools">
          <button type="button" @click="blankGift">新建空白祝福</button>
          <button type="button" @click="draft = cloneCurrent()">载入当前页面内容</button>
          <button type="button" @click="fileInput?.click()">导入内容文件</button>
          <button type="button" @click="exportFile">导出内容文件</button>
          <input ref="fileInput" type="file" accept=".json,application/json" aria-label="导入内容文件" hidden tabindex="-1" @change="importFile" />
        </div>
        <p class="privacy-note">内容保存在本机草稿和生成的链接里。拿到链接的人都能阅读，姓名入口只是开场互动，请勿写入隐私资料。</p>
        <a href="./source.html" target="_blank" rel="noopener">原版特效的来源与源码</a>
      </aside>
      <div class="editor-fields">
        <section aria-labelledby="basic-title">
          <h2 id="basic-title">这份礼物，送给谁</h2>
          <div class="basic-fields">
            <label v-for="field in fields" :key="field.key" :for="`edit-${field.key}`">{{ field.label }}
              <input :id="`edit-${field.key}`" v-model="draft[field.key]" :maxlength="field.max" :required="field.required ?? false" :autocomplete="field.key === 'recipient' ? 'off' : undefined" />
            </label>
          </div>
        </section>
        <section aria-labelledby="story-title">
          <h2 id="story-title">把回忆写成故事</h2>
          <label for="edit-story-title">故事标题<input id="edit-story-title" v-model="draft.storyTitle" maxlength="60" required /></label>
          <label for="edit-epigraph">题记（可留空）<input id="edit-epigraph" v-model="draft.epigraph" maxlength="200" /></label>
          <fieldset v-for="(chapter, index) in draft.chapters" :key="index" class="chapter-fields">
            <legend>第 {{ index + 1 }} 章</legend>
            <label :for="`chapter-${index}-title`">章节标题<input :id="`chapter-${index}-title`" v-model="chapter.title" maxlength="80" required /></label>
            <label :for="`chapter-${index}-body`">正文（换行分段）<textarea :id="`chapter-${index}-body`" v-model="chapter.body" rows="7" maxlength="7000" required /></label>
            <label :for="`chapter-${index}-quote`">章末引语（可留空）<textarea :id="`chapter-${index}-quote`" v-model="chapter.quote" rows="2" maxlength="300" /></label>
            <label :for="`chapter-${index}-closing`">章末强调语（可留空）<input :id="`chapter-${index}-closing`" v-model="chapter.closing" maxlength="300" /></label>
            <button v-if="chapterCount > 1" type="button" :aria-label="`删除第 ${index + 1} 章`" @click="draft.chapters.splice(index, 1)">删除这一章</button>
          </fieldset>
          <button type="button" :disabled="chapterCount >= 12" @click="draft.chapters.push({ title: '', body: '', quote: '', closing: '' })">添加章节</button>
        </section>
        <section aria-labelledby="wish-title">
          <h2 id="wish-title">留几句心里话</h2>
          <label for="edit-wishes-title">寄语页标题<input id="edit-wishes-title" v-model="draft.wishesTitle" maxlength="60" required /></label>
          <div v-for="(_, index) in draft.wishes" :key="index" class="wish-field">
            <label :for="`wish-${index}`">寄语 {{ index + 1 }}<textarea :id="`wish-${index}`" v-model="draft.wishes[index]" rows="3" maxlength="1000" required /></label>
            <button v-if="draft.wishes.length > 1" type="button" :aria-label="`删除寄语 ${index + 1}`" @click="draft.wishes.splice(index, 1)">删除</button>
          </div>
          <button type="button" :disabled="draft.wishes.length >= 12" @click="draft.wishes.push('')">添加寄语</button>
          <label for="edit-blessing">最后的祝福<input id="edit-blessing" v-model="draft.blessing" maxlength="200" required /></label>
          <label for="edit-signature">署名（可留空）<input id="edit-signature" v-model="draft.signature" maxlength="80" /></label>
        </section>
        <section v-if="link" class="share-result" aria-labelledby="share-title">
          <h2 id="share-title">把这份祝福送出去</h2>
          <label for="gift-share-link">完整专属链接<textarea id="gift-share-link" :value="link" readonly rows="3" @focus="($event.target as HTMLTextAreaElement).select()" /></label>
          <div class="share-actions"><button type="button" @click="copyLink">复制完整链接</button><a :href="link" target="_blank" rel="noopener">打开收礼人页面</a></div>
          <p>链接包含这一次的全部内容。之后修改草稿，需要重新生成并发送新链接。</p>
        </section>
      </div>
      <footer class="editor-actions">
        <div class="editor-message"><p v-if="error" role="alert" class="editor-error">{{ error }}</p><p v-else role="status">{{ note || '先填写，再预览。草稿会自动保存在本机。' }}</p></div>
        <button type="submit">预览效果</button><button type="button" class="primary" :disabled="busy" @click="makeLink">{{ busy ? '生成中…' : '生成专属链接' }}</button>
      </footer>
    </form>
  </dialog>
</template>

<style scoped>
.gift-editor { --ink: #29263d; --muted: #605b70; --line: #cecbd8; margin: auto; padding: 0; width: min(1120px, calc(100% - 40px)); max-width: none; height: min(920px, calc(100dvh - 40px)); max-height: none; border: 1px solid #aaa4bb; border-radius: 14px; color: var(--ink); background: #f7f7fb; overflow: auto; overscroll-behavior: contain; }
.gift-editor::backdrop { background: #030712bd; backdrop-filter: blur(8px); }
.editor-heading { display: flex; align-items: flex-start; gap: 16px; justify-content: space-between; padding: 32px; background: #edeaf5; border-bottom: 1px solid var(--line); }
h1 { font-family: 'Songti SC', SimSun, serif; font-size: clamp(26px, 3vw, 36px); font-weight: 600; margin: 0 0 8px; }
.editor-heading p, .editor-guide p, .share-result p { line-height: 1.7; color: var(--muted); font-size: 14px; }
.editor-form { display: grid; grid-template-columns: 220px minmax(0, 1fr); gap: 32px; padding: 32px 32px 0; }
.editor-guide p { margin-bottom: 16px; }.file-tools { display: grid; gap: 8px; margin: 24px 0; }
a { color: #553685; text-decoration: underline; text-underline-offset: 4px; line-height: 1.8; }
.editor-fields { min-width: 0; }section { margin-bottom: 40px; }h2 { font-size: 22px; font-weight: 600; margin-bottom: 24px; }
.basic-fields { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0 20px; }
label { display: block; font-size: 14px; color: var(--ink); line-height: 1.7; margin-bottom: 20px; }
input, textarea { display: block; width: 100%; min-width: 0; margin-top: 8px; border: 1px solid #a5a0b3; border-radius: 6px; padding: 11px 12px; font: inherit; font-size: 16px; line-height: 1.65; color: #29263d; background: #fff; }
textarea { resize: vertical; }input:focus, textarea:focus { outline: 2px solid #69459b; outline-offset: 2px; }
button { min-height: 44px; padding: 10px 16px; border: 1px solid #9e95b3; border-radius: 6px; background: #fff; color: #44325c; font-size: 14px; }
button:hover { background: #eee9f7; }button:disabled { opacity: .5; cursor: default; }.close-editor { flex-shrink: 0; }
.chapter-fields { min-width: 0; margin: 28px 0; padding: 20px; border: 1px solid var(--line); border-radius: 8px; background: #fff; }legend { padding: 0 8px; font-weight: 600; }.chapter-fields label:last-of-type { margin-bottom: 12px; }
.wish-field { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 12px; align-items: start; }.wish-field button { margin-top: 32px; }
.wish-field + button { margin-bottom: 24px; }.share-result { border-top: 2px solid #8760b3; padding-top: 24px; }.share-actions { display: flex; gap: 24px; align-items: center; margin-bottom: 16px; }
.editor-actions { grid-column: 1 / -1; position: sticky; bottom: 0; display: flex; flex-wrap: wrap; gap: 12px; align-items: center; padding: 16px 0 max(16px, env(safe-area-inset-bottom)); background: #f7f7fbfa; border-top: 1px solid var(--line); }
.editor-message { flex: 1; min-width: 180px; font-size: 13px; line-height: 1.6; color: var(--muted); }.editor-error { color: #a52337; }.primary { color: #fff; background: #65428a; border-color: #65428a; }.primary:hover { background: #51346f; }
@media (max-width: 740px) { .gift-editor { width: 100%; height: 100dvh; border-radius: 0; border: 0; }.editor-heading { padding: 24px 20px; }.editor-heading p { max-width: 28ch; }.editor-form { grid-template-columns: 1fr; padding: 24px 20px 0; gap: 24px; }.editor-guide { border-bottom: 1px solid var(--line); padding-bottom: 24px; }.file-tools { grid-template-columns: 1fr 1fr; margin: 16px 0; }.basic-fields { grid-template-columns: 1fr; }.editor-actions { gap: 8px; }.editor-message { flex-basis: 100%; }.editor-actions button { flex: 1; }.chapter-fields { padding: 16px; }.close-editor { padding-inline: 12px; }.share-actions { gap: 16px; flex-wrap: wrap; } }
</style>
