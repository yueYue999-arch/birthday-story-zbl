<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import FluidSimBackground from './FluidSimBackground.vue'
import type { GiftContent } from '../content'
defineProps<{ isActive: boolean; gift: GiftContent }>()
defineEmits<{ next: [] }>()
const interactionCount = ref(0)
const content = ref<HTMLDivElement | null>(null)
const overflowing = ref(false)
let observer: ResizeObserver
onMounted(() => {
  observer = new ResizeObserver(() => {
    overflowing.value = !!content.value && content.value.scrollHeight > content.value.clientHeight + 2
  })
  observer.observe(content.value!)
})
onUnmounted(() => observer?.disconnect())
</script>

<template>
  <section class="birthday-page">
    <FluidSimBackground :is-active="isActive" @interact="interactionCount++" />
    <div class="readability-shade" aria-hidden="true" />
    <div ref="content" class="birthday-content" :class="{ overflowing, compact: gift.recipient.length + gift.greeting.length > 18 }">
      <p v-if="gift.date" class="birthday-date">{{ gift.date }}</p>
      <h1 tabindex="-1"><span>{{ gift.greeting }}，</span><strong>{{ gift.recipient }}！</strong></h1>
      <p v-if="gift.subtitle" class="subtitle">{{ gift.subtitle }}</p>
      <p v-if="gift.english" class="english" lang="en">{{ gift.english }}</p>
      <button class="story-button" @click="$emit('next')">打开你的故事</button>
    </div>
    <p class="touch-hint" aria-live="polite">{{ overflowing ? '上下滑动阅读，边缘拖动光影' : interactionCount ? '这一刻，因你而闪耀' : '按住并划动，点亮这一刻' }}</p>
  </section>
</template>

<style scoped>
.birthday-page { position: relative; width: 100%; height: 100%; overflow: hidden; background: #080912; }
.readability-shade { position: absolute; inset: 0; pointer-events: none; background: radial-gradient(ellipse at 50% 44%, #080912a6, #08091218 72%), linear-gradient(#08091288, transparent 18%, transparent 75%, #08091288); }
.birthday-content { overflow-y: auto; overscroll-behavior: contain; position: absolute; inset: max(68px, calc(env(safe-area-inset-top) + 60px)) 24px calc(128px + env(safe-area-inset-bottom)); display: flex; flex-direction: column; align-items: center; justify-content: safe center; padding: 16px 0; text-align: center; pointer-events: none; }
.birthday-content > * { flex-shrink: 0; }
.birthday-content.overflowing { pointer-events: auto; touch-action: pan-y pinch-zoom; }
.birthday-date { color: #e2dce9; font-size: 14px; letter-spacing: .2em; margin-bottom: 32px; text-shadow: 0 2px 16px #000; }
h1 { max-width: 100%; display: flex; flex-wrap: wrap; justify-content: center; gap: .12em; font-size: clamp(44px, 7.5vw, 112px); line-height: 1.2; font-weight: 700; letter-spacing: -.04em; color: #fff; text-shadow: 0 3px 28px #0008; }
h1 span, h1 strong { max-width: 100%; overflow-wrap: anywhere; }
h1 strong { font-weight: inherit; }
.subtitle { margin-top: 28px; font-size: clamp(15px, 2vw, 22px); color: #e2e8f0; line-height: 1.8; text-shadow: 0 2px 14px #000; }
.english { margin-top: 8px; font-size: 15px; color: #d8d7e4; font-style: italic; }
.story-button { pointer-events: auto; margin-top: 32px; min-height: 48px; padding: 12px 24px; border: 1px solid #ffffff6b; border-radius: 8px; background: #101222b3; color: #fff; font-size: 16px; }
.story-button:hover { background: #23263ceb; }
.touch-hint { position: absolute; bottom: calc(94px + env(safe-area-inset-bottom)); left: 50%; transform: translateX(-50%); width: max-content; max-width: calc(100% - 32px); text-align: center; pointer-events: none; color: #e2e8f0; font-size: 13px; padding: 6px 12px; border-radius: 20px; background: #080912b3; }
@media (max-width: 600px) { h1 { flex-direction: column; gap: 8px; font-size: clamp(42px, 11vw, 66px); }.birthday-date { margin-bottom: 24px; } }
.compact h1 { font-size: clamp(26px, 6vw, 64px); }
@media (max-height: 520px) { .birthday-content { bottom: calc(84px + env(safe-area-inset-bottom)); padding: 8px 0; }.birthday-date { margin-bottom: 8px; }h1 { flex-direction: row; font-size: clamp(28px, 5vw, 52px); }.subtitle { margin-top: 8px; }.english, .touch-hint { display: none; }.story-button { margin-top: 10px; } }
</style>

