export interface Chapter {
  title: string
  body: string
  quote: string
  closing: string
  closingAfter?: number
}
export interface GiftContent {
  version: 1
  id: string
  recipient: string
  invitation: string
  greeting: string
  date: string
  subtitle: string
  english: string
  storyTitle: string
  epigraph: string
  chapters: Chapter[]
  wishesTitle: string
  wishes: string[]
  blessing: string
  signature: string
}

export const draftKey = 'birthday-gift-draft-v1'
export const maxContentBytes = 100_000
export const maxShareLength = 16_000

// All imported/link content is plain text, validated at this external boundary.
export function validateGift(input: unknown): GiftContent {
  if (!input || typeof input !== 'object') throw new Error('内容格式不正确，请导入本页面导出的 JSON。')
  const data = input as Record<string, unknown>
  if (data.version !== 1) throw new Error('内容版本不支持，请使用版本 1 的内容文件。')
  function text(value: unknown, label: string, max: number, optional = false) {
    if (typeof value !== 'string' || (!optional && !value.trim()) || value.length > max) {
      throw new Error(`${label}${optional ? '' : '不能为空，且'}最多 ${max} 字。`)
    }
    return value.trim()
  }
  const id = text(data.id, '礼物编号', 64)
  if (!/^[a-zA-Z0-9_-]+$/.test(id)) throw new Error('礼物编号格式不正确。')
  if (!Array.isArray(data.chapters) || data.chapters.length < 1 || data.chapters.length > 12) throw new Error('请保留 1–12 个故事章节。')
  if (!Array.isArray(data.wishes) || data.wishes.length < 1 || data.wishes.length > 12) throw new Error('请保留 1–12 条寄语。')
  const gift: GiftContent = {
    version: 1, id,
    recipient: text(data.recipient, '名字', 30),
    invitation: text(data.invitation, '邀请语', 100),
    greeting: text(data.greeting, '首页祝福', 30),
    date: text(data.date, '日期', 40, true),
    subtitle: text(data.subtitle, '首页副标题', 120, true),
    english: text(data.english, '英文祝福', 80, true),
    storyTitle: text(data.storyTitle, '故事标题', 60),
    epigraph: text(data.epigraph, '题记', 200, true),
    chapters: data.chapters.map((item, index) => {
      if (!item || typeof item !== 'object') throw new Error(`第 ${index + 1} 章格式不正确。`)
      return {
        title: text(item.title, '章节标题', 80),
        body: text(item.body, '章节正文', 7000),
        quote: text(item.quote, '章末引语', 300, true),
        closing: text(item.closing, '章末强调语', 300, true),
        ...(Number.isInteger(item.closingAfter) && item.closingAfter >= 0 && item.closingAfter < 1000 ? { closingAfter: item.closingAfter } : {}),
      }
    }),
    wishesTitle: text(data.wishesTitle, '寄语标题', 60),
    wishes: data.wishes.map(item => text(item, '寄语', 1000)),
    blessing: text(data.blessing, '最后的祝福', 200),
    signature: text(data.signature, '署名', 80, true),
  }
  if (new TextEncoder().encode(JSON.stringify(gift)).length > maxContentBytes) throw new Error('内容太长，请缩短故事后再试。')
  return gift
}

export async function encodeGift(gift: GiftContent): Promise<string> {
  const data = validateGift(gift)
  const stream = new Blob([JSON.stringify(data)]).stream().pipeThrough(new CompressionStream('gzip'))
  const bytes = new Uint8Array(await new Response(stream).arrayBuffer())
  const encoded = btoa(Array.from(bytes, byte => String.fromCharCode(byte)).join(''))
    .replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '')
  if (encoded.length > maxShareLength) throw new Error('专属链接太长，请缩短正文；也可以先导出内容文件留存。')
  return `#gift=${encoded}`
}

export async function decodeGift(hash: string): Promise<GiftContent | null> {
  if (!hash.startsWith('#gift=')) return null
  const encoded = hash.slice(6)
  if (!encoded || encoded.length > maxShareLength || !/^[\w-]+$/.test(encoded)) throw new Error('专属链接不完整或太长，请向送礼人索取完整链接。')
  try {
    const bytes = Uint8Array.from(atob(encoded.replaceAll('-', '+').replaceAll('_', '/')), character => character.charCodeAt(0))
    const reader = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip')).getReader()
    const chunks: Uint8Array[] = []
    let size = 0
    try {
      while (true) {
        const { value, done } = await reader.read()
        if (done) break
        size += value.byteLength
        if (size > maxContentBytes) throw new Error('链接内容超过大小限制。')
        chunks.push(value)
      }
    } finally { await reader.cancel().catch(() => {}) }
    const data = new Uint8Array(size)
    let offset = 0
    for (const chunk of chunks) { data.set(chunk, offset); offset += chunk.byteLength }
    return validateGift(JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(data)))
  } catch {
    throw new Error('专属链接无法读取，请复制完整链接，或用新版 Safari、Chrome 打开。')
  }
}

export function shareBase(location: string) {
  const url = new URL(location)
  url.search = ''
  url.hash = ''
  return url.href
}
