import { createApp } from 'vue'
import App from './App.vue'
import './style.css'
import { registerOffline } from './pwa'

createApp(App).mount('#app')
if (import.meta.env.PROD) void registerOffline()
