const progressKey = (id: string) => `birthday-${id}-progress-v1`
export const storyPositionKey = (id: string) => `birthday-${id}-story-position-v1`

export function parseProgress(raw: string | null): { page: number } | null {
  if (!raw) return null
  try {
    const value = JSON.parse(raw)
    return value && Number.isInteger(value.page) && value.page >= 0 && value.page < 3
      ? { page: value.page } : null
  } catch { return null }
}
export function loadProgress(id = 'zbl') {
  try { return parseProgress(localStorage.getItem(progressKey(id))) } catch { return null }
}
export function saveProgress(page: number, id = 'zbl') {
  try { localStorage.setItem(progressKey(id), JSON.stringify({ page })) } catch { /* 隐私模式下仍允许浏览。 */ }
}
export function clearProgress(id = 'zbl') {
  try { localStorage.removeItem(progressKey(id)); localStorage.removeItem(storyPositionKey(id)) } catch { /* 存储禁用不影响重新开始。 */ }
}
export function pageForKey(page: number, key: string, editing: boolean): number {
  if (editing) return page
  if (key === 'ArrowRight') return Math.min(2, page + 1)
  if (key === 'ArrowLeft') return Math.max(0, page - 1)
  return page
}

