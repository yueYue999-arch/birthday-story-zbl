let registration: ServiceWorkerRegistration | undefined
let refreshing = false

export function applyUpdate() {
  if (!registration) return
  if (!registration.waiting) { window.location.reload(); return }
  refreshing = true
  registration.waiting.postMessage({ type: 'SKIP_WAITING' })
}

export async function registerOffline() {
  if (!('serviceWorker' in navigator)) return
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (refreshing) window.location.reload()
  })
  const announceUpdate = () => window.dispatchEvent(new Event('gift-update-ready'))
  try {
    registration = await navigator.serviceWorker.register(`${import.meta.env.BASE_URL}sw.js`, { updateViaCache: 'none' })
    if (registration.waiting) announceUpdate()
    registration.addEventListener('updatefound', () => {
      const worker = registration!.installing
      worker?.addEventListener('statechange', () => {
        if (worker.state === 'installed' && navigator.serviceWorker.controller) announceUpdate()
      })
    })
    await navigator.serviceWorker.ready
    window.dispatchEvent(new Event('gift-offline-ready'))
  } catch (error) {
    console.warn('离线保存暂不可用，联网浏览不受影响。', error)
  }
}
