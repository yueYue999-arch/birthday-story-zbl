# 祝福网页：对应前端源码

这是随当前网页提供的可修改、可重新构建的前端源码。用户填写的草稿、专属链接内容均不提交到本源码包。默认公开个案仍为朱博乐。

## 本地运行与修改

需要 Node.js 22.18.0 或 >=24.12.0，以及 npm。首次安装依赖需要网络。

```sh
npm ci
npm test
npm run build
npm run preview -- --host 127.0.0.1 --port 17645
```

打开终端显示的网址；编辑入口为 `/?edit=1`。修改 `src/default-gift.json` 更换默认个案；`src/content.ts` 是配置接口与链接编解码；`src/components/GiftEditor.vue` 为可视化编辑器。

构建输出 `output/site`，其中包含当前对应源码 `frontend-source.zip`。将整个 site 目录放到支持 HTTPS 的静态站点即可；支持子目录，不需要服务器数据库。包内 package.json 的 deploy 命令面向原维护工作区，公开包不含部署账号配置；独立部署请使用自己的静态托管账号。

## 许可与来源

本次组合前端按 GPL-3.0 提供；本次新增代码和修改同样按 GPL-3.0 提供。允许依据许可使用、修改、重新构建和分发，不提供担保；分发修改版本时应保留声明并提供对应源码。第三方部分保留各自版权和原许可。页面中的个人故事文字不因此自动获得独立素材授权。

- `GalaxyBackground.vue`：FrankWkd-Plus/galaxy-theme-portfolio，GPL v3。对照提交 `a16f4e32089575cd595c76bd205b6a3ddfbb8b6b`。原仓库 LICENSE 原样保存在 `public/licenses/galaxy-upstream.txt`；通用 GPL v3 全文在 `public/licenses/GPL-3.0.txt`。
- `GridAnimationBackground.vue`：SimonAKing/HomePage/src/js/main.js，LGPL-3.0；对照提交 `19b90161b231cd64bd9c3aeb2afc723e04259df8`，全文在 `public/licenses/LGPL-3.0.txt`。在本组合包中可用源码修改并重新链接构建。
- `FluidSimBackground.vue`：Pavel Dobryakov 的 WebGL Fluid Simulation，经 HomePage 引入；文件级 MIT。
- Three.js、Vue、Tailwind CSS：MIT；构建源码 ZIP 使用 fflate（MIT），不参与浏览器运行。

改动日期：2026-09-20。保留原星空呼吸、粒子配色、双环几何、网格移动与蛇尾交互；修改输入、帧率独立运动、像素倍率、缩放、资源释放与异常回退；增加跨端布局、内容配置、专属链接、草稿与离线支持。原 ZIP 的历史未使用组件未纳入本包。

详细版权声明见 `public/third-party-notices.txt` 和 `public/licenses/`。已识别开源来源的交付义务与未知文字、旧布局的权利链是不同事项；本包不是“所有素材均已核清”的法律结论。
