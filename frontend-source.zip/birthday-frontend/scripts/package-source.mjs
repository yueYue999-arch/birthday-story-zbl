import { readFile, readdir, writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
import { zipSync } from 'fflate'

const root = fileURLToPath(new URL('../', import.meta.url))
// Only the running frontend and its build inputs. No archive, credentials,
// deployment account configuration, local drafts, reports or old components.
const files = [
  'package.json', 'package-lock.json', 'index.html', 'env.d.ts',
  'tsconfig.json', 'tsconfig.app.json', 'tsconfig.node.json', 'vite.config.ts',
  'SOURCE-README.md', 'src/App.vue', 'src/main.ts', 'src/style.css', 'src/pwa.ts',
  'src/navigation.ts', 'src/content.ts', 'src/default-gift.json',
  ...['LoginPage', 'ParticlePage', 'StoryPage', 'WishesPage', 'GiftEditor',
    'GalaxyBackground', 'WishLightBackground', 'FluidSimBackground', 'AmbientBackground']
    .map(name => `src/components/${name}.vue`),
  'scripts/package-source.mjs', 'scripts/prepare-release.mjs', 'scripts/check-live.mjs',
  'tests/navigation.test.mjs', 'tests/content.test.mjs',
]
async function includeDirectory(directory) {
  for (const entry of await readdir(path.join(root, directory), { withFileTypes: true })) {
    const relative = `${directory}/${entry.name}`
    if (entry.isDirectory()) await includeDirectory(relative)
    else if (!entry.name.startsWith('_')) files.push(relative)
  }
}
await includeDirectory('public')
const contents = {}
for (const file of files.sort()) contents[`birthday-frontend/${file}`] = new Uint8Array(await readFile(path.join(root, file)))
const archive = zipSync(contents, { level: 6 })
await writeFile(path.join(root, 'output/site/frontend-source.zip'), archive)
console.log(`Corresponding frontend source: ${files.length} files, ${archive.length} bytes`)
