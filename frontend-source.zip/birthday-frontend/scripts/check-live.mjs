// Read-only release health check. Run after publication or when a recipient
// reports a failure; this script does not schedule a monitor or change hosting.
const sites = process.argv.slice(2).length ? process.argv.slice(2) : [
  'https://yueyue999-arch.github.io/birthday-story-zbl/',
  'https://birthday-story-zbl.fusion-portfolio.workers.dev/',
]
async function get(url) {
  const response = await fetch(url, { signal: AbortSignal.timeout(20_000), cache: 'no-store' })
  if (!response.ok) throw new Error(`${url} HTTP ${response.status}`)
  return response
}
const results = await Promise.allSettled(sites.map(async site => {
  const index = await (await get(site + '?release-check=' + Date.now())).text()
  const js = index.match(/src="([^"\s]+\.js)"/)?.[1]
  const css = index.match(/href="([^"\s]+\.css)"/)?.[1]
  if (!js || !css) throw new Error(`${site} 未找到运行资源`)
  const files = [js, css, 'sw.js', 'source.html', 'frontend-source.zip']
  for (const file of files) {
    const response = await get(new URL(file, site))
    if (file.endsWith('.zip')) {
      const bytes = new Uint8Array(await response.arrayBuffer())
      if (bytes[0] !== 80 || bytes[1] !== 75) throw new Error(`${site} 源码下载不是 ZIP`)
    } else if (file !== 'source.html' && (response.headers.get('content-type') ?? '').includes('text/html')) {
      throw new Error(`${site} ${file} 返回了错误的 HTML 页面`)
    }
  }
  return { site, status: 'ok', js, css, checked: new Date().toISOString() }
}))
for (const result of results) {
  if (result.status === 'fulfilled') console.log(JSON.stringify(result.value))
  else { console.error(result.reason.message); process.exitCode = 1 }
}
