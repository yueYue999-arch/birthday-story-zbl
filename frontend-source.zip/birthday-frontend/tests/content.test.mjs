import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { encodeGift, decodeGift, validateGift, maxContentBytes, shareBase } from '../src/content.ts'
import { clearProgress, loadProgress, saveProgress, storyPositionKey } from '../src/navigation.ts'

const original = JSON.parse(readFileSync(new URL('../src/default-gift.json', import.meta.url), 'utf8'))
test('原个案完整压缩还原，包含中文、七章正文和段落顺序标记', async () => {
  assert.equal(original.chapters.length, 7)
  const hash = await encodeGift(original)
  assert.ok(hash.length < 16_006)
  assert.deepEqual(await decodeGift(hash), original)
  assert.equal(original.chapters[6].closingAfter, 6)
})
test('新姓名、表情和 HTML 字面文本经过专属链接后保持原样', async () => {
  const gift = structuredClone(original)
  gift.id = 'recipient-2'
  gift.recipient = '小满🎂'
  gift.chapters[0].body = '<img src=x onerror=alert(1)>\n\n今天见到你真好 & 明天也一样。'
  assert.deepEqual(await decodeGift(await encodeGift(gift)), gift)
  assert.equal(shareBase('https://example.com/gift/?edit=1#old'), 'https://example.com/gift/')
})
test('空名、错误章节、超长字段与未知版本得到明确拒绝', () => {
  for (const invalid of [null, {}, { ...original, version: 9 }, { ...original, recipient: ' ' },
    { ...original, chapters: [] }, { ...original, wishes: [null] },
    { ...original, recipient: '长'.repeat(31) }, { ...original, id: '../other' }]) {
    assert.throws(() => validateGift(invalid))
  }
})
test('损坏或被截断的链接不可静默变成原个案', async () => {
  assert.equal(await decodeGift(''), null)
  assert.equal(await decodeGift('#section'), null)
  for (const hash of ['#gift=', '#gift=broken', '#gift=xx!', '#gift=' + 'a'.repeat(16001)]) {
    await assert.rejects(decodeGift(hash))
  }
  const valid = await encodeGift(original)
  await assert.rejects(decodeGift(valid.slice(0, -8)))
})
test('高压缩比超大内容在解压边界被拒绝', async () => {
  const stream = new Blob(['x'.repeat(maxContentBytes + 1)]).stream().pipeThrough(new CompressionStream('gzip'))
  const buffer = Buffer.from(await new Response(stream).arrayBuffer())
  await assert.rejects(decodeGift('#gift=' + buffer.toString('base64url')))
})
test('不同礼物的入口、页码和故事续读相互隔离', () => {
  const values = new Map()
  const previous = Object.getOwnPropertyDescriptor(globalThis, 'localStorage')
  Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: {
    getItem: key => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value),
    removeItem: key => values.delete(key),
  } })
  try {
    saveProgress(2, 'zbl')
    assert.equal(loadProgress('custom'), null)
    saveProgress(1, 'custom')
    values.set(storyPositionKey('zbl'), '900')
    values.set(storyPositionKey('custom'), '100')
    clearProgress('custom')
    assert.deepEqual(loadProgress('zbl'), { page: 2 })
    assert.equal(values.get(storyPositionKey('zbl')), '900')
    assert.equal(loadProgress('custom'), null)
  } finally {
    if (previous) Object.defineProperty(globalThis, 'localStorage', previous)
    else delete globalThis.localStorage
  }
})
