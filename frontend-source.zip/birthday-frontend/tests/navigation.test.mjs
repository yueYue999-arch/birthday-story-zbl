import { test } from 'node:test'
import assert from 'node:assert/strict'
import { parseProgress, pageForKey } from '../src/navigation.ts'

test('损坏或越界的进度重新从姓名入口开始', () => {
  for (const raw of [null, '', '{', 'null', '[]', '{"page":-1}', '{"page":3}', '{"page":0.5}', '{"page":"1"}']) {
    assert.equal(parseProgress(raw), null)
  }
  for (const page of [0, 1, 2]) assert.deepEqual(parseProgress(JSON.stringify({ page })), { page })
})
test('方向键切页有边界，不抢输入、按钮和空格的默认行为', () => {
  assert.equal(pageForKey(0, 'ArrowLeft', false), 0)
  assert.equal(pageForKey(0, 'ArrowRight', false), 1)
  assert.equal(pageForKey(1, 'ArrowRight', false), 2)
  assert.equal(pageForKey(2, 'ArrowRight', false), 2)
  assert.equal(pageForKey(2, 'ArrowLeft', false), 1)
  for (const key of [' ', 'Enter', 'ArrowUp', 'ArrowDown']) assert.equal(pageForKey(1, key, false), 1)
  for (const key of ['ArrowRight', 'ArrowLeft']) assert.equal(pageForKey(1, key, true), 1)
})
