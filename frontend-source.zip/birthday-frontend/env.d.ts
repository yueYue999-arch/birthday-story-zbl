/// <reference types="vite/client" />

interface Window {
  FluidSimulation?: any
}
